"""
Verification of the four things added when the universe was widened: the event
filter, the liquidity screen, the Trading 212 mapping and the crypto board.

The standard this file has to meet was set by an earlier failure. Five suites
passed while a fatal bug sat in scan.py, because no test ran scan.py and the
synthetic harness duplicated the pipeline instead of calling it. So every check
here runs the real function on the real code path, and the ones guarding a
specific defect are written so that removing the fix makes them fail.
"""
import sys, os, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from weinstein import (events as EV, liquidity as LQ, t212 as T212,
                       crypto as CR, synth, features as F)

GRADES = ["A", "B", "C", "D"]
ORDER = {g: i for i, g in enumerate(GRADES)}


def _rec(grade="A"):
    return {"ticker": "TEST", "grade": grade,
            "signal": {"kind": "stage2_breakout", "grade": grade, "notes": ""}}


def main():
    bad = []

    # =====================================================================
    # 1. EVENTS
    # =====================================================================
    asof = dt.date(2026, 8, 21)

    # 1a. The GFRD.L case, which is why this module exists. The 15 July trading
    # statement produced a breakout stamped the week of 20 July: the event is in
    # the PRECEDING week, so a naive "is the event inside the signal week" test
    # misses it entirely.
    info = EV.classify([dt.date(2026, 7, 15)], asof, dt.date(2026, 7, 20))
    print(f"GFRD-shaped case: status={info['event_status']}, "
          f"near_signal={info['event_near_signal']}, days_to_next={info['days_to_event']}")
    if not info["event_near_signal"]:
        bad.append("an event in the week before the signal was not detected")
    if info["event_status"] != EV.STATUS_DRIVEN:
        bad.append(f"expected event_driven, got {info['event_status']}")

    # And the same line a month earlier, when 17 September results ARE inside
    # the four week window, must report both facts rather than only one.
    both = EV.classify([dt.date(2026, 7, 15), dt.date(2026, 9, 17)],
                       dt.date(2026, 8, 27), dt.date(2026, 7, 20))
    if both["event_status"] != EV.STATUS_BOTH:
        bad.append(f"expected event_driven_and_ahead, got {both['event_status']}")

    # 1b. An event far away in both directions is clear.
    clear = EV.classify([dt.date(2026, 1, 10), dt.date(2026, 12, 1)],
                        asof, dt.date(2026, 7, 20))
    if clear["event_status"] != EV.STATUS_CLEAR:
        bad.append(f"a diary with nothing near should be clear, got {clear['event_status']}")

    # 1c. Missing data must not read as a clean diary. This is the same rule the
    # scoring layer follows, and the reason the "one minus" terms were rewritten.
    unknown = EV.classify(None, asof, dt.date(2026, 7, 20))
    if unknown["event_status"] != EV.STATUS_UNKNOWN:
        bad.append("a failed event lookup did not report unknown")
    if EV.CAP.get(EV.STATUS_UNKNOWN) is not None:
        bad.append("unknown event data penalises the grade, which punishes thin "
                   "data coverage rather than a bad chart")
    if not unknown["event_note"]:
        bad.append("unknown event status carries no explanation, so it reads as clear")

    # 1d. Exhaustive: nothing an event flag does may ever RAISE a grade.
    raised = []
    for g in GRADES:
        for st in (EV.STATUS_CLEAR, EV.STATUS_AHEAD, EV.STATUS_DRIVEN,
                   EV.STATUS_BOTH, EV.STATUS_UNKNOWN, EV.STATUS_NA):
            out = EV.apply(_rec(g), {"event_status": st, "next_event": None,
                                     "days_to_event": 3, "event_near_signal": False,
                                     "event_note": "note"})
            ng = out["signal"]["grade"]
            if ORDER[ng] < ORDER[g]:
                raised.append((g, st, ng))
    print(f"event grade monotonicity: {len(raised)} case(s) where a flag raised a grade")
    if raised:
        bad.append(f"event flags raised a grade: {raised[:4]}")

    # 1e. The caps actually bite.
    driven = EV.apply(_rec("A"), EV.classify([dt.date(2026, 7, 18)], asof,
                                             dt.date(2026, 7, 20)))
    if driven["grade"] != "C":
        bad.append(f"an event-driven A was not capped to C, got {driven['grade']}")
    ahead = EV.apply(_rec("A"), EV.classify([dt.date(2026, 9, 5)], asof, None))
    if ahead["grade"] != "B":
        bad.append(f"results inside the window did not cap an A to B, got {ahead['grade']}")

    # 1f. Cache round trip, including the FAILED sentinel, which is what keeps a
    # failed lookup from being retried as if it had never happened.
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "events.csv")
        EV._save({"AAA": [dt.date(2026, 3, 1)], "BBB": None},
                 {"AAA": asof, "BBB": asof}, path)
        back = EV.fetch(["AAA", "BBB"], asof=asof, cache_path=path, verbose=False)
        if back.get("AAA") != [dt.date(2026, 3, 1)]:
            bad.append(f"event cache lost a date: {back.get('AAA')}")
        if back.get("BBB") is not None:
            bad.append("a cached failure came back as a successful empty diary, "
                       "which reads as 'no events' rather than 'not known'")

    # =====================================================================
    # 2. LIQUIDITY
    # =====================================================================
    idx = pd.date_range("2024-01-01", periods=60, freq="W-MON")

    def line(price, vol):
        return pd.DataFrame({"open": price, "high": price * 1.02, "low": price * 0.98,
                             "close": price, "volume": vol}, index=idx)

    # 2a. Pence. A London line at 600p trading 200k shares a week is £1.2m a
    # week, not £120m. Getting this wrong makes every UK name look a hundred
    # times more liquid than it is and defeats the entire screen.
    uk = LQ.measure(line(600.0, 200_000), "ABC.L", usd_gbp=0.79)
    expect = 600.0 * 200_000 * 0.01 / 5.0
    print(f"UK pence conversion: £{uk['adv_gbp']:,.0f}/day (expected £{expect:,.0f})")
    if abs(uk["adv_gbp"] - expect) > 1.0:
        bad.append(f"pence conversion wrong: {uk['adv_gbp']} vs {expect}")

    us = LQ.measure(line(60.0, 200_000), "ABC", usd_gbp=0.79)
    if abs(us["adv_gbp"] - 60.0 * 200_000 * 0.79 / 5.0) > 1.0:
        bad.append("dollar conversion wrong")

    # 2b. Statuses land where they should.
    thin = LQ.measure(line(100.0, 3_000), "THIN", usd_gbp=0.79)
    dead = LQ.measure(line(100.0, 200), "DEAD", usd_gbp=0.79)
    fat = LQ.measure(line(100.0, 5_000_000), "FAT", usd_gbp=0.79)
    print(f"liquidity statuses: thin={thin['liquidity_status']} "
          f"(£{thin['adv_gbp']:,.0f}), dead={dead['liquidity_status']}, "
          f"fat={fat['liquidity_status']}")
    if thin["liquidity_status"] != LQ.STATUS_THIN:
        bad.append(f"a thin line was not flagged thin: {thin}")
    if dead["liquidity_status"] != LQ.STATUS_UNTRADEABLE:
        bad.append(f"an untradeable line was not flagged: {dead}")
    if fat["liquidity_status"] != LQ.STATUS_OK:
        bad.append(f"a liquid line was flagged: {fat}")

    # 2c. Zero-volume weeks are caught even when the average looks respectable.
    # This is the failure the average alone cannot see: two block trades and
    # twenty dead weeks average out to a number that looks fine.
    blocky = line(100.0, 0)
    blocky.iloc[::10, blocky.columns.get_loc("volume")] = 20_000_000
    b = LQ.measure(blocky, "BLOCK", usd_gbp=0.79)
    print(f"blocky line: {b['dead_weeks']} dead weeks, status {b['liquidity_status']}")
    if b["liquidity_status"] == LQ.STATUS_OK:
        bad.append("a line that trades one week in ten was graded ok")

    # 2d. Unusable data is unknown, not ok.
    if LQ.measure(pd.DataFrame(), "X", 0.79)["liquidity_status"] != LQ.STATUS_UNKNOWN:
        bad.append("an empty price frame did not report unknown liquidity")

    # 2e. Monotonicity again.
    raised = []
    for g in GRADES:
        for st in (LQ.STATUS_OK, LQ.STATUS_THIN, LQ.STATUS_UNTRADEABLE, LQ.STATUS_UNKNOWN):
            out = LQ.apply(_rec(g), {"liquidity_status": st, "adv_gbp": 1.0,
                                     "dead_weeks": 0, "amihud": 0.1,
                                     "liquidity_note": "n"})
            if ORDER[out["signal"]["grade"]] < ORDER[g]:
                raised.append((g, st, out["signal"]["grade"]))
    if raised:
        bad.append(f"liquidity flags raised a grade: {raised[:4]}")

    # 2f. FX falls back rather than failing, and the fallback is not silent.
    if abs(LQ.fx_usd_gbp({}) - 0.79) > 1e-9:
        bad.append("missing FX series did not fall back to the stated default")
    fx = LQ.fx_usd_gbp({LQ.FX_TICKER: pd.DataFrame({"close": [1.25]},
                                                   index=[idx[0]])})
    if abs(fx - 0.8) > 1e-6:
        bad.append(f"GBPUSD 1.25 should give 0.80 GBP per USD, got {fx}")

    # =====================================================================
    # 3. TRADING 212 MAPPING
    # =====================================================================
    cases = [
        ("MCRB_US_EQ", "US1234567890", "USD", ("MCRB", "US")),
        ("BPl_EQ", "GB0007980591", "GBX", ("BP.L", "UK")),
        ("VODl_EQ", "GB00BH4HKS39", "GBP", ("VOD.L", "UK")),
        ("AAPL_US_EQ", "US0378331005", "GBP", None),   # currency contradicts shape
        ("SOMEl_EQ", "US0378331005", "GBP", None),     # ISIN contradicts shape
        ("BTC_EQ", "", "USD", None),                   # not an equity shape at all
        ("", "", "", None),
    ]
    wrong = [(t, T212.parse_ticker(t, i, c), want)
             for t, i, c, want in cases if T212.parse_ticker(t, i, c) != want]
    print(f"t212 ticker mapping: {len(cases) - len(wrong)} of {len(cases)} correct")
    if wrong:
        bad.append(f"t212 ticker mapping wrong: {wrong}")

    uni = pd.DataFrame([
        {"ticker": "AAPL", "name": "Apple", "sector": "Tech", "market": "US", "index": "SP500"},
        {"ticker": "VOD.L", "name": "Vodafone", "sector": "Telecom", "market": "UK", "index": "FTSE100"},
        {"ticker": "GONE", "name": "Delisted", "sector": "Tech", "market": "US", "index": "SP500"},
    ])
    trade = T212.tradeable_frame(pd.DataFrame([
        {"ticker": "AAPL_US_EQ", "name": "Apple", "isin": "US0378331005",
         "currencyCode": "USD", "type": "STOCK"},
        {"ticker": "VODl_EQ", "name": "Vodafone", "isin": "GB00BH4HKS39",
         "currencyCode": "GBX", "type": "STOCK"},
        {"ticker": "TINYl_EQ", "name": "Tiny plc", "isin": "GB00B0000001",
         "currencyCode": "GBX", "type": "STOCK"},
    ]))

    # 3a. A failed broker call must not empty the scan. This is the difference
    # between "the broker is down" and "nothing is tradeable".
    safe = T212.apply_to_universe(uni, pd.DataFrame(), restrict=True, extend=True)
    print(f"empty broker list: universe kept {len(safe)} of {len(uni)} rows")
    if len(safe) != len(uni):
        bad.append("an empty broker list emptied the universe instead of being "
                   "treated as unknown")

    # 3b. Restrict drops the untradeable, extend adds what no index covers, and
    # the index row keeps its sector when both describe the same company.
    both_on = T212.apply_to_universe(uni, trade, restrict=True, extend=True)
    tickers = set(both_on["ticker"])
    print(f"tradeability pass: {sorted(tickers)}")
    if "GONE" in tickers:
        bad.append("an untradeable name survived the restrict pass")
    if "TINY.L" not in tickers:
        bad.append("a tradeable name outside every index was not added")
    vod = both_on[both_on["ticker"] == "VOD.L"]
    if vod.empty or str(vod.iloc[0]["sector"]) != "Telecom":
        bad.append("the broker row overwrote an index row's sector, which would "
                   "disable the group factor for a name that had one")
    if len(both_on) != len(set(both_on["ticker"])):
        bad.append("the tradeability pass produced duplicate tickers")

    # =====================================================================
    # 4. CRYPTO
    # =====================================================================
    # 4a. The Sunday week boundary, checked across a full week of as-of dates.
    # The equity rule here would call a week finished two days early.
    wk = pd.date_range("2026-08-03", periods=4, freq="W-MON")     # Monday stamps
    df = pd.DataFrame({"open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0,
                       "volume": 1.0}, index=wk)
    last_stamp = wk[-1].date()                                    # Mon 24 Aug
    wrong_days = []
    for off in range(0, 9):
        d = last_stamp + dt.timedelta(days=off)
        kept = len(CR.drop_partial_week(df, asof=d)) == len(df)
        # The bar covering Mon 24th to Sun 30th is only complete after the 30th.
        should_keep = d > dt.date(2026, 8, 30)
        if kept != should_keep:
            wrong_days.append((d.isoformat(), kept, should_keep))
    print(f"crypto Sunday boundary: {len(wrong_days)} of 9 as-of dates wrong")
    if wrong_days:
        bad.append(f"crypto week boundary wrong on {wrong_days}")

    # 4b. The scalar is measured and bounded.
    calm = {"a": pd.DataFrame({"atr_pct": [4.0] * 60})}
    wild = {"a": pd.DataFrame({"atr_pct": [12.0] * 60})}
    insane = {"a": pd.DataFrame({"atr_pct": [400.0] * 60})}
    ks = (CR.vol_scale(calm), CR.vol_scale(wild), CR.vol_scale(insane), CR.vol_scale({}))
    print(f"volatility scalars: calm={ks[0]:.2f} wild={ks[1]:.2f} "
          f"insane={ks[2]:.2f} empty={ks[3]:.2f}")
    if abs(ks[0] - 1.0) > 1e-9:
        bad.append("an equity-volatility board did not get a scalar of 1.0")
    if abs(ks[1] - 3.0) > 1e-9:
        bad.append(f"a 3x-volatility board got a scalar of {ks[1]}")
    if ks[2] > CR.SCALE_MAX + 1e-9:
        bad.append("the scalar is not bounded above")
    if abs(ks[3] - 1.0) > 1e-9:
        bad.append("an empty board did not fall back to no rescaling")

    # 4c. Rescaling touches the percentage columns and nothing else. A scaled
    # close or volume would corrupt every price level on the board.
    feat = pd.DataFrame({"close": [100.0], "volume": [1000.0], "resistance": [110.0],
                         "px_vs_ma_pct": [30.0], "vol_ratio": [2.5],
                         "base_width_pct": [60.0], "base_age_weeks": [20.0]})
    r = CR.rescale(feat, 3.0)
    checks = {"close": 100.0, "volume": 1000.0, "resistance": 110.0,
              "vol_ratio": 2.5, "base_age_weeks": 20.0,
              "px_vs_ma_pct": 10.0, "base_width_pct": 20.0}
    off = {c: (float(r[c].iloc[0]), v) for c, v in checks.items()
           if abs(float(r[c].iloc[0]) - v) > 1e-9}
    print(f"rescale: {len(checks) - len(off)} of {len(checks)} columns correct")
    if off:
        bad.append(f"rescale altered the wrong columns: {off}")
    if not CR.rescale(feat, 1.0).equals(feat):
        bad.append("a scalar of 1.0 still modified the frame")

    # 4d. End to end on synthetic coins, through the REAL crypto.run, and then
    # the point of the whole exercise: without rescaling, does the board behave
    # differently? If the answer is no, the calibration is decoration.
    _, _, prices, _ = synth.build_universe()
    coins = {}
    for i, (t, d) in enumerate(sorted(prices.items())[:12]):
        amp = d.copy()
        base = float(amp["close"].iloc[0])
        # Triple the WEEKLY RETURN, then rebuild the path. Amplifying the level
        # about a fixed base leaves weekly range roughly where it was, so the
        # ATR barely moves and the scalar stays at 1.0 -- which is exactly the
        # trap this fixture fell into the first time it was written.
        r = amp["close"].pct_change().fillna(0.0)
        new_close = base * (1.0 + 3.0 * r).clip(lower=0.02).cumprod()
        for c in ("open", "high", "low"):
            amp[c] = new_close * (d[c] / d["close"])
        amp["close"] = new_close
        # Widen the weekly bar to match: an amplified path with the original
        # intrabar range would understate the volatility it is meant to have.
        mid = amp[["open", "close"]].mean(axis=1)
        amp["high"] = mid + 3.0 * (d["high"] - d[["open", "close"]].mean(axis=1)) \
            * (new_close / d["close"])
        amp["low"] = mid - 3.0 * (d[["open", "close"]].mean(axis=1) - d["low"]) \
            * (new_close / d["close"])
        amp["low"] = amp["low"].clip(lower=amp["close"] * 0.05)
        amp["high"] = amp[["high", "open", "close"]].max(axis=1)
        amp["low"] = amp[["low", "open", "close"]].min(axis=1)
        coins[f"C{i}-USD"] = amp
    res = CR.run(prices=coins, coins=list(coins), keep_partial=True)
    scan = res["scan"]
    print(f"crypto board: {len(scan)} coins scored, scalar {res['vol_scale']:.2f}, "
          f"regime {res.get('market', {}).get('regime')}")
    if scan.empty:
        bad.append("the crypto board produced no rows at all")
    else:
        if not (res["vol_scale"] > 1.0):
            bad.append(f"amplified series did not raise the scalar: {res['vol_scale']}")
        # Displayed numbers must be the real ones, not the equity-equivalent
        # ones the scoring ran on.
        raw = F.compute_features(coins[scan.iloc[0]["ticker"]],
                                 CR.composite(coins))
        shown = scan.iloc[0].get("px_vs_ma_pct")
        actual = raw["px_vs_ma_pct"].iloc[-1]
        if shown is not None and pd.notna(actual) and abs(float(shown) - float(actual)) > 1e-6:
            bad.append(f"the board displays rescaled numbers ({shown}) rather than "
                       f"the real ones ({actual})")
        # And the calibration has to change something.
        flat = CR.run(prices=coins, coins=list(coins), keep_partial=True)
        import weinstein.crypto as _cr
        old_ref = _cr.EQUITY_REF_ATR_PCT
        try:
            _cr.EQUITY_REF_ATR_PCT = 1e9        # forces a scalar of 1.0: no rescaling
            unscaled = CR.run(prices=coins, coins=list(coins), keep_partial=True)
        finally:
            _cr.EQUITY_REF_ATR_PCT = old_ref
        def latecount(s):
            return sum(1 for r in s.to_dict("records")
                       if isinstance(r.get("signal"), dict)
                       and r["signal"].get("status") == "late")
        a, b = latecount(flat["scan"]), latecount(unscaled["scan"])
        print(f"signals marked late: {a} with calibration, {b} without "
              f"(scalar {flat['vol_scale']:.2f} vs {unscaled['vol_scale']:.2f})")
        if abs(unscaled["vol_scale"] - 1.0) > 1e-9:
            bad.append("the unscaled control run still rescaled")
        if b < a:
            bad.append("rescaling made MORE signals read as late, which is backwards")

    print("\n" + ("FAILURES:\n  " + "\n  ".join(bad) if bad
                  else "EXPANSION CHECKS PASSED"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
