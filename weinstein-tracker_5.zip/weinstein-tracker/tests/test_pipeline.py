"""
End-to-end exercise of the REAL scan pipeline, offline.

This exists because of a bug that reached production. `scan.run` contained

    bench = benches.get(market) or next(iter(benches.values()))

and a pandas Series has no truth value, so that line raises the moment the
market IS found. Every offline test passed, because the test harness in
synth.py reimplements the pipeline rather than calling it: the module that
actually runs on the runner had no test touching it at all.

So this drives `scan.run` itself, with the network replaced by injected prices
and a supplied universe file rather than by mocking internals. Anything that
raises anywhere between the universe and the rendered HTML fails here.
"""
import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
from weinstein import scan as SC, report as R, universe as U, plan as PL

RNG = np.random.default_rng(31)
N = 260
IDX = pd.date_range(end=pd.Timestamp("2026-08-21"), periods=N, freq="W-FRI")


def series(start, drift, vol, n=None):
    n = n or len(IDX)
    c = start * np.cumprod(1 + drift + RNG.normal(0, vol, n))
    hi = c * (1 + np.abs(RNG.normal(0, .006, n)) + .005)
    lo = c * (1 - np.abs(RNG.normal(0, .006, n)) - .005)
    v = np.abs(RNG.normal(1.2e6, 3e5, n)) + 1e5
    return pd.DataFrame({"open": c, "high": hi, "low": lo, "close": c, "volume": v},
                        index=IDX[:n])


def main():
    bad = []
    n = len(IDX)

    prices, rows = {}, []
    for market, suffix, sectors in (("US", "", ["Technology", "Health Care"]),
                                    ("UK", ".L", ["Industrials", "Financials"])):
        for si, sec in enumerate(sectors):
            for j in range(7):
                t = f"{market[0]}{si}{j}{suffix}"
                prices[t] = series(40 + 10 * j, 0.002 + 0.001 * si, 0.022)
                rows.append({"ticker": t, "name": f"{sec} co {j}", "sector": sec,
                             "market": market, "index": f"{market}IDX"})
    # Benchmarks under the names the code expects, so the market lookup that
    # caused the original crash is genuinely exercised for BOTH markets.
    for m, bt in U.BENCHMARKS.items():
        prices[bt] = series(1000, 0.0015, 0.012)
    print(f"universe {len(rows)} tickers across {len({r['market'] for r in rows})} markets, "
          f"benchmarks {sorted(U.BENCHMARKS.values())}")

    with tempfile.TemporaryDirectory() as tmp:
        upath = os.path.join(tmp, "universe.csv")
        pd.DataFrame(rows).to_csv(upath, index=False)

        try:
            res = SC.run([], years=5, use_cache=True, keep_partial=True,
                         calibrate=True, min_price=1.0,
                         plan_cfg=PL.PlanConfig(account_size=20_000.0, risk_pct=1.0),
                         positions=[], prices=prices, universe_file=upath)
        except Exception as e:                        # noqa: BLE001
            import traceback; traceback.print_exc()
            print(f"\nFAILURES:\n  scan.run raised {type(e).__name__}: {e}")
            return 1

        scan = res["scan"]
        print(f"scored {len(scan)} tickers, {len(res['sectors'])} sector composites, "
              f"regime {res['market'].get('regime')}")
        if scan.empty:
            bad.append("scan.run produced no records")
        for key in ("market", "sectors", "calibration", "regime_history", "positions"):
            if key not in res:
                bad.append(f"result is missing '{key}'")
        if not res["market"].get("regime"):
            bad.append("no market regime was computed")
        if len(res["sectors"]) < 2:
            bad.append(f"expected several sector composites, got {len(res['sectors'])}")

        # Both markets must have been scored, which is what the crash prevented.
        if not scan.empty:
            markets = set(scan["market"])
            print(f"markets scored: {sorted(markets)}")
            if markets != {"US", "UK"}:
                bad.append(f"expected both markets, got {sorted(markets)}")
            for col in ("stage", "trend_score", "stage2_readiness", "explain",
                        "prompt_vals", "plan"):
                if col not in scan.columns:
                    bad.append(f"records are missing '{col}'")
            ex = scan["explain"].dropna()
            if len(ex) and not str(ex.iloc[0].get("action", "")):
                bad.append("the plain-English panel produced no action text")

        lists = SC.slice_lists(scan, top=10)
        print("lists: " + ", ".join(f"{k}={len(v)}" for k, v in lists.items()))
        try:
            html = R.build_html(lists, scan, res["calibration"], res["asof"],
                                res["generated"], market=res["market"],
                                sectors=res["sectors"],
                                regime_history=res["regime_history"],
                                positions=res["positions"])
        except Exception as e:                        # noqa: BLE001
            import traceback; traceback.print_exc()
            bad.append(f"build_html raised {type(e).__name__}: {e}")
            html = ""
        if html:
            import json, re
            m = re.search(r"const D = (\{.*?\});\n", html, re.S)
            if not m:
                bad.append("the dashboard payload is not parseable")
            else:
                try:
                    json.loads(m.group(1))
                    print(f"dashboard rendered, {len(html):,} bytes, payload is valid JSON")
                except Exception as e:                # noqa: BLE001
                    bad.append(f"dashboard payload is not valid JSON: {e}")
            if "__DATA__" in html:
                bad.append("the template placeholder was not substituted")

    print("\n" + ("FAILURES:\n  " + "\n  ".join(bad) if bad else "PIPELINE RUNS END TO END"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
