# Pre-trade check

Paste this into Claude before placing any order, with the placeholders filled in
from the ticker's row on the dashboard. The dashboard's "Copy pre-trade check"
button fills them for you; this file is the template it uses, kept here so you
can read it, edit it, and see exactly what is being asked.

It is deliberately adversarial. A prompt that asks "is this a good setup" gets
agreement, because agreement is the path of least resistance for a model handed
a confident-looking table. This one asks for the reasons not to, and demands an
explicit verdict with the single strongest objection named.

Two of its checks now exist because live audits found the defect they catch.
"Is this a company at all" is there because a closed-end fund once reached the
top of a live Stage 2 breakout list and passed every Weinstein test on the way.
"Interrogate the volume" is there because three consecutive checks found the
breakout week was a results-day reaction rather than accumulation.

---

You are checking a single stock before I place a real order. Assume the
setup is flawed and try to find out how. If you cannot find a flaw, say so plainly, but
look first.

## What my scanner says

Ticker: {ticker} ({name}), {market} listing, {sector} sector
Scan week ending: {asof}
Stage: {stage}          Trend score: {trend_score} (-100 to +100)
Signal: {signal}        Grade: {grade}
Price at that close: {close}
Typical daily value traded: {adv_gbp} (liquidity screen: {liquidity_status})

Weinstein conditions AS OF THE SCAN WEEK (see the signal-week block below if
the signal is not from this week, because these are not the numbers it fired on):
- 30 week average: {ma30}, slope {ma_slope_pct}% over 5 weeks
- Price vs that average: {px_vs_ma_pct}%
- Mansfield relative strength: {mansfield_rs} (4 week change {rs_slope}), measured
  against an EQUAL-WEIGHTED composite of the scanned universe rather than the headline
  index. The same stock reads {mansfield_rs_cap} against the cap-weighted index. Where
  those two disagree sharply, the stock is being carried or buried by a handful of
  mega-caps rather than by anything happening in its own group.
- Sector relative strength: {sector_rs}, this stock vs its own sector: {rs_vs_sector}
- Base: {base_age_weeks} weeks old, {base_width_pct}% wide, resistance {resistance}, support {support}
- Breakout volume: {vol_ratio_3w}x the ten week average (textbook wants 2.0x)
- Market regime: {regime}

What the scanner already checked automatically, for you to verify rather than repeat:
- Results diary: {event_status}{event_detail}
- Index rebalance proximity: {rebalance_status}{rebalance_detail}
{at_signal_block}
Warnings the scanner itself raised on this plan:
{plan_notes}

The breakout plan it produced:
- Entry trigger {trigger}, pullback zone {pullback_low} to {pullback_high}
- Stop {stop} ({risk_pct}% risk)
- Target 1 {t1} ({t1_r}R), target 2 {t2} ({t2_r}R)
{pullback_block}
## What I need you to do

1. Get current data. Search for {ticker}'s price now and its recent weekly closes.
   My numbers are from the week ending {asof} and may be several days stale. If price
   has already run past the trigger or broken the stop, say so first, because that
   changes the trade rather than merely dating it.

2. Check this is a company at all, before anything else. Stage analysis assumes an
   operating business whose shares institutions accumulate. It does not apply to a
   closed-end fund, an investment trust, an ETF or ETN, a royalty trust, a SPAC or a
   shell, whose price is net asset value times a discount that moves on its own
   schedule. If it is one of those, stop there and say so: every Weinstein test can
   pass on an instrument the method was never about.

3. Re-derive the four Weinstein conditions yourself from a current chart rather than
   trusting my table: price above a 30 week average that is flat or rising, relative
   strength positive, a real base of at least eight weeks rather than a pause in a
   downtrend, and volume expansion on the breakout week. Tell me which of the four you
   can confirm, which you cannot, and which of my numbers are wrong. On relative
   strength, say explicitly whether it beats its peers or only beats the index.

4. Interrogate the volume, do not just read it. Weinstein's 2x rule is a proxy for
   institutions accumulating over weeks. In a market where a large share of volume
   prints off-exchange and passive funds buy on a schedule, a single heavy week can be
   an index rebalance, a block print, an options-hedging flow or one results-day gap,
   all of which clear the same bar and mean something completely different. Ask whether
   the expansion was sustained across several weeks or concentrated in one session, and
   what caused it.

5. Look for what a weekly OHLCV scan structurally cannot see:
   - a results date, capital markets day or major regulatory decision inside the next
     four weeks, which turns a chart trade into an event bet
   - an index inclusion, deletion or reconstitution that explains the move as forced
     flow rather than conviction, and will not repeat
   - a takeover approach, a placing, an at-the-market programme, a profit warning
   - a share consolidation, split, spin-off or ticker change that corrupts the price
     history the base was measured from
   - dilution, going-concern language, or a heavily shorted float, and whether a
     crowded short is what is actually driving the move
   - unusual options open interest near my trigger or stop, which can pin or squeeze
     price for reasons unrelated to the business
   - liquidity: at {adv_gbp} a day, is my position a small fraction of normal flow,
     and what is the spread I will actually cross
   - for a UK line, whether it is priced in pence, whether my levels match, and whether
     stamp duty and the spread are material against a stop this wide

6. Check the trade shape, not just the setup. Which entry am I actually taking, the
   breakout or the pullback, and is the plan I have the right one for it? Is the stop
   somewhere the chart would genuinely invalidate the idea, or an arbitrary percentage?
   Is the first target at a real prior level or floating in space? Would this position
   be correlated with what I already hold, by sector, by theme, or by the same
   macro driver?

7. Give me a verdict in this form and nothing more elaborate:
   VERDICT: GO / NO / WAIT
   The single strongest reason against it, in one sentence.
   What specifically would have to change for the answer to become GO.

Do not be agreeable. If the honest answer is that the setup is thin, say it is thin.
If my scanner's numbers disagree with what you find, my scanner is more likely to be
wrong than the market is.
