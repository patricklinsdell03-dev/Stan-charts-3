"""
The pre-trade check prompt.

A weekly scan is a filter over twelve hundred charts. It has never looked at the
one chart you are about to trade, it cannot see anything that is not in weekly
OHLCV, and by the time you place the order it is between one and six days stale.
This builds a prompt that hands an assistant the scan's own numbers and asks it
to try to talk you out of the trade.

It is written to be adversarial on purpose. A prompt that asks "is this a good
setup" gets agreement, because agreement is the path of least resistance for a
model handed a confident-looking table. This one asks for the reasons not to,
and requires an explicit verdict with the single strongest objection named.
"""

from __future__ import annotations

TEMPLATE = """You are checking a single stock before I place a real order. Assume the
setup is flawed and try to find out how. If you cannot find a flaw, say so plainly, but
look first.

## What my scanner says

Ticker: {ticker} ({name}), {market} listing, {sector} sector
Scan week ending: {asof}
Stage: {stage}          Trend score: {trend_score} (-100 to +100)
Signal: {signal}        Grade: {grade}
Price at that close: {close}
Typical daily value traded: {adv_gbp} (liquidity screen: {liquidity_status})

Weinstein conditions AS OF THE SCAN WEEK (see the signal-week block below if
the signal is not from this week, because these are not the numbers it fired on):
- 30 week average: {ma30}, slope {ma_slope_pct}% over 5 weeks
- Price vs that average: {px_vs_ma_pct}%
- Mansfield relative strength: {mansfield_rs} (4 week change {rs_slope}), measured
  against an EQUAL-WEIGHTED composite of the scanned universe rather than the headline
  index. The same stock reads {mansfield_rs_cap} against the cap-weighted index. Where
  those two disagree sharply, the stock is being carried or buried by a handful of
  mega-caps rather than by anything happening in its own group.
- Sector relative strength: {sector_rs}, this stock vs its own sector: {rs_vs_sector}
- Base: {base_age_weeks} weeks old, {base_width_pct}% wide, resistance {resistance}, support {support}
- Breakout volume: {vol_ratio_3w}x the ten week average (textbook wants 2.0x)
- Market regime: {regime}

What the scanner already checked automatically, for you to verify rather than repeat:
- Results diary: {event_status}{event_detail}
- Index rebalance proximity: {rebalance_status}{rebalance_detail}
{at_signal_block}
Warnings the scanner itself raised on this plan:
{plan_notes}

The breakout plan it produced:
- Entry trigger {trigger}, pullback zone {pullback_low} to {pullback_high}
- Stop {stop} ({risk_pct}% risk)
- Target 1 {t1} ({t1_r}R), target 2 {t2} ({t2_r}R)
{pullback_block}
## What I need you to do

1. Get current data. Search for {ticker}'s price now and its recent weekly closes.
   My numbers are from the week ending {asof} and may be several days stale. If price
   has already run past the trigger or broken the stop, say so first, because that
   changes the trade rather than merely dating it.

2. Check this is a company at all, before anything else. Stage analysis assumes an
   operating business whose shares institutions accumulate. It does not apply to a
   closed-end fund, an investment trust, an ETF or ETN, a royalty trust, a SPAC or a
   shell, whose price is net asset value times a discount that moves on its own
   schedule. If it is one of those, stop there and say so: every Weinstein test can
   pass on an instrument the method was never about.

3. Re-derive the four Weinstein conditions yourself from a current chart rather than
   trusting my table: price above a 30 week average that is flat or rising, relative
   strength positive, a real base of at least eight weeks rather than a pause in a
   downtrend, and volume expansion on the breakout week. Tell me which of the four you
   can confirm, which you cannot, and which of my numbers are wrong. On relative
   strength, say explicitly whether it beats its peers or only beats the index.

4. Interrogate the volume, do not just read it. Weinstein's 2x rule is a proxy for
   institutions accumulating over weeks. In a market where a large share of volume
   prints off-exchange and passive funds buy on a schedule, a single heavy week can be
   an index rebalance, a block print, an options-hedging flow or one results-day gap,
   all of which clear the same bar and mean something completely different. Ask whether
   the expansion was sustained across several weeks or concentrated in one session, and
   what caused it.

5. Look for what a weekly OHLCV scan structurally cannot see:
   - a results date, capital markets day or major regulatory decision inside the next
     four weeks, which turns a chart trade into an event bet
   - an index inclusion, deletion or reconstitution that explains the move as forced
     flow rather than conviction, and will not repeat
   - a takeover approach, a placing, an at-the-market programme, a profit warning
   - a share consolidation, split, spin-off or ticker change that corrupts the price
     history the base was measured from
   - dilution, going-concern language, or a heavily shorted float, and whether a
     crowded short is what is actually driving the move
   - unusual options open interest near my trigger or stop, which can pin or squeeze
     price for reasons unrelated to the business
   - liquidity: at {adv_gbp} a day, is my position a small fraction of normal flow,
     and what is the spread I will actually cross
   - for a UK line, whether it is priced in pence, whether my levels match, and whether
     stamp duty and the spread are material against a stop this wide

6. Check the trade shape, not just the setup. Which entry am I actually taking, the
   breakout or the pullback, and is the plan I have the right one for it? Is the stop
   somewhere the chart would genuinely invalidate the idea, or an arbitrary percentage?
   Is the first target at a real prior level or floating in space? Would this position
   be correlated with what I already hold, by sector, by theme, or by the same
   macro driver?

7. Give me a verdict in this form and nothing more elaborate:
   VERDICT: GO / NO / WAIT
   The single strongest reason against it, in one sentence.
   What specifically would have to change for the answer to become GO.

Do not be agreeable. If the honest answer is that the setup is thin, say it is thin.
If my scanner's numbers disagree with what you find, my scanner is more likely to be
wrong than the market is.
"""

EXTRA = ["at_signal_block", "plan_notes", "pullback_block",
         "event_detail", "rebalance_detail"]
FIELDS = ["ticker", "name", "market", "sector", "asof", "stage", "trend_score",
          "signal", "grade", "close", "ma30", "ma_slope_pct", "px_vs_ma_pct",
          "mansfield_rs", "rs_slope", "sector_rs", "rs_vs_sector",
          "base_age_weeks", "base_width_pct", "resistance", "support",
          "vol_ratio_3w", "regime", "trigger", "pullback_low", "pullback_high",
          "stop", "risk_pct", "t1", "t1_r", "t2", "t2_r",
          "mansfield_rs_cap", "adv_gbp", "liquidity_status",
          "event_status", "rebalance_status"]


def _pct(now, then):
    try:
        return (float(now) / float(then) - 1.0) * 100.0
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def _fmt(v, dp=2):
    if v is None:
        return "not available"
    try:
        return f"{float(v):,.{dp}f}"
    except (TypeError, ValueError):
        return str(v)


def fields(rec: dict, asof: str = "", regime: str = "") -> dict:
    """
    The substitution values for one record.

    Separated from `build` so the dashboard can ship the template once and fill
    it in the browser, rather than embedding a two-kilobyte prompt per row.
    One template, one set of field names, no drift between the file you can read
    and the button you press.
    """
    p = rec.get("plan") or {}
    sig = rec.get("signal") or {}
    kind = sig.get("kind")
    sig_txt = "none, this has not broken out" if not kind else (
        f"{kind}, {'confirmed' if sig.get('confirmed') else 'unconfirmed'}"
        f", {int(rec.get('signal_age_weeks') or 0)} "
        f"{'week' if int(rec.get('signal_age_weeks') or 0) == 1 else 'weeks'} ago")
    vals = {
        "ticker": rec.get("ticker", ""), "name": rec.get("name") or "name not recorded",
        "market": rec.get("market", ""), "sector": rec.get("sector") or "unclassified",
        "asof": asof or "unknown", "stage": rec.get("stage", ""),
        "trend_score": _fmt(rec.get("trend_score"), 0), "signal": sig_txt,
        "grade": rec.get("grade") or "not graded",
        "close": _fmt(rec.get("close")), "ma30": _fmt(rec.get("ma30")),
        "ma_slope_pct": _fmt(rec.get("ma_slope_pct")),
        "px_vs_ma_pct": _fmt(rec.get("px_vs_ma_pct"), 1),
        "mansfield_rs": _fmt(rec.get("mansfield_rs"), 1),
        "rs_slope": _fmt(rec.get("rs_slope"), 1),
        "sector_rs": _fmt(rec.get("sector_rs"), 1),
        "rs_vs_sector": _fmt(rec.get("rs_vs_sector"), 1),
        "base_age_weeks": _fmt(rec.get("base_age_recent") or rec.get("base_age_weeks"), 0),
        "base_width_pct": _fmt(rec.get("base_width_pct"), 1),
        "resistance": _fmt(rec.get("resistance")), "support": _fmt(rec.get("support")),
        "vol_ratio_3w": _fmt(rec.get("vol_ratio_3w"), 1),
        "regime": regime or "not recorded",
        "trigger": _fmt(p.get("trigger")), "pullback_low": _fmt(p.get("pullback_low")),
        "pullback_high": _fmt(p.get("pullback_high")), "stop": _fmt(p.get("stop")),
        "risk_pct": _fmt(p.get("risk_pct"), 1), "t1": _fmt(p.get("t1")),
        "t1_r": _fmt(p.get("t1_r"), 1), "t2": _fmt(p.get("t2")),
        "t2_r": _fmt(p.get("t2_r"), 1),
        # The old cap-weighted reading, carried so the checker can see whether a
        # weak number means the stock is lagging its peers or only lagging the
        # handful of mega-caps that now dominate the headline index.
        "mansfield_rs_cap": _fmt(rec.get("mansfield_rs_cap"), 1),
        "adv_gbp": (f"£{float(rec['adv_gbp']):,.0f}"
                    if rec.get("adv_gbp") is not None else "not measured"),
        "liquidity_status": rec.get("liquidity_status") or "not measured",
        "event_status": rec.get("event_status") or "not checked",
        "rebalance_status": rec.get("rebalance_status") or "not checked",
    }

    # Detail lines for the two automated flags. Stated so the checker VERIFIES
    # what the scanner found rather than rediscovering it, and so a silent
    # "unknown" cannot be mistaken for a clean diary.
    nxt, days = rec.get("next_event"), rec.get("days_to_event")
    if nxt and days is not None:
        vals["event_detail"] = f" — next event {nxt}, in {int(days)} day(s)"
    elif rec.get("event_status") == "unknown":
        vals["event_detail"] = (" — no results date could be found for this line, "
                                "so the event risk is UNMEASURED rather than absent. "
                                "Find it yourself.")
    else:
        vals["event_detail"] = ""
    vals["rebalance_detail"] = (f" — {rec['rebalance_event']}"
                                if rec.get("rebalance_event") else "")

    pb = rec.get("pullback_plan") or {}
    if pb:
        vals["pullback_block"] = (
            "\nThe PULLBACK plan, which is a different trade on the same stock:\n"
            f"- Buy limit {_fmt(pb.get('pullback_high'))} at the 30 week average\n"
            f"- Stop {_fmt(pb.get('stop'))} ({_fmt(pb.get('risk_pct'), 1)}% risk), "
            "below both the average and the recent swing low\n"
            f"- Target 1 {_fmt(pb.get('t1'))} ({_fmt(pb.get('t1_r'), 1)}R) at the prior high, "
            f"target 2 {_fmt(pb.get('t2'))} ({_fmt(pb.get('t2_r'), 1)}R)\n"
            "Tell me which of the two entries is the one worth taking here, and say so "
            "explicitly. They have different stops, different risk and different odds, "
            "and taking one plan's entry with the other plan's stop is how a good setup "
            "becomes a bad trade.\n")
    else:
        vals["pullback_block"] = ""

    notes = p.get("notes") or []
    vals["plan_notes"] = ("\n".join(f"- {n}" for n in notes) if notes
                          else "- none")

    at = sig.get("at_signal") or {}
    if at:
        vals["at_signal_block"] = (
            f"\nAS OF THE WEEK THE SIGNAL ACTUALLY FIRED ({at.get('date')}), which is what\n"
            f"the confirmed/grade verdict was based on:\n"
            f"- Close then: {_fmt(at.get('close'))}, resistance broken: {_fmt(at.get('resistance'))}\n"
            f"- Breakout volume then: {_fmt(at.get('vol_ratio_3w'), 1)}x\n"
            f"- Base then: {_fmt(at.get('base_age_weeks'), 0)} weeks old, "
            f"{_fmt(at.get('base_width_pct'), 1)}% wide\n"
            f"- Relative strength then: {_fmt(at.get('mansfield_rs'), 1)}, "
            f"price vs 30w average then: {_fmt(at.get('px_vs_ma_pct'), 1)}%\n"
            f"The stock has moved {_fmt(_pct(rec.get('close'), at.get('close')), 1)}% since,\n"
            f"so treat this as a signal you are considering LATE rather than a fresh one.\n")
    else:
        vals["at_signal_block"] = ""
    return vals


def build(rec: dict, asof: str = "", regime: str = "") -> str:
    """Fill the template from one scored record."""
    return TEMPLATE.format(**fields(rec, asof, regime))
