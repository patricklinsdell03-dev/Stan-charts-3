"""
The forward log must be a record, not an opinion.

Two properties matter and neither is obvious from reading the code. What the
scanner said at the time must never change on a later run, or the log stops being
evidence and becomes a rolling restatement of current belief. And outcomes must
accumulate as weeks pass, or there is nothing to learn from.

Both are checked by running the real pipeline twice against the same prices,
truncated for the first run and complete for the second, which is exactly what
happens week to week.
"""
import sys, os, tempfile, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
from weinstein import scan as SC, universe as U, journal as J, plan as PL

RNG = np.random.default_rng(77)
IDX = pd.date_range(end=pd.Timestamp("2026-08-21"), periods=200, freq="W-FRI")


def path(start, drift, vol, n):
    c = start * np.cumprod(1 + drift + RNG.normal(0, vol, n))
    hi = c * (1 + np.abs(RNG.normal(0, .008, n)) + .006)
    lo = c * (1 - np.abs(RNG.normal(0, .008, n)) - .006)
    v = np.abs(RNG.normal(1.4e6, 4e5, n)) + 2e5
    return pd.DataFrame({"open": c, "high": hi, "low": lo, "close": c, "volume": v},
                        index=IDX[:n])


def main():
    bad = []
    n = len(IDX)
    prices, rows = {}, []
    for si, sec in enumerate(["Technology", "Industrials"]):
        for j in range(7):
            t = f"J{si}{j}"
            prices[t] = path(30 + 8 * j, 0.0022 + 0.0008 * si, 0.026, n)
            rows.append({"ticker": t, "name": f"{sec} {j}", "sector": sec,
                         "market": "US", "index": "TESTIDX"})
    for bt in set(U.BENCHMARKS.values()):
        prices[bt] = path(2000, 0.0015, 0.011, n)

    tmp = tempfile.mkdtemp()
    logp = os.path.join(tmp, "signals.csv")
    upath = os.path.join(tmp, "universe.csv")
    pd.DataFrame(rows).to_csv(upath, index=False)
    orig = J.SIGNALS
    J.SIGNALS = logp
    try:
        def run(weeks):
            cut = {t: df.iloc[:weeks] for t, df in prices.items()}
            return SC.run([], years=4, use_cache=True, keep_partial=True,
                          calibrate=False, prices=cut, universe_file=upath,
                          plan_cfg=PL.PlanConfig())

        # --- week one -----------------------------------------------------
        import weinstein.journal as JJ
        real_update = JJ.update
        JJ.update = lambda *a, **k: real_update(*a, **{**k, "path": logp}) \
            if "path" not in k else real_update(*a, **k)
        run(n - 12)
        if not os.path.exists(logp):
            print("FAILURES:\n  the scan did not write a log at all")
            return 1
        first = pd.read_csv(logp)
        print(f"first run: {len(first)} signals logged")
        if first.empty:
            print("FAILURES:\n  the log is empty after a run that produced signals")
            return 1

        # --- twelve weeks later -------------------------------------------
        run(n)
        second = pd.read_csv(logp)
        print(f"second run: {len(second)} signals logged "
              f"({len(second) - len(first)} new)")

        # 1. frozen columns must be untouched for rows that already existed
        common = set(first["signal_id"]) & set(second["signal_id"])
        a = first[first["signal_id"].isin(common)].set_index("signal_id").sort_index()
        b = second[second["signal_id"].isin(common)].set_index("signal_id").sort_index()
        changed = []
        for c in J.FROZEN:
            if c == "signal_id":
                continue
            x, y = a[c].astype(str), b[c].astype(str)
            if not x.equals(y):
                changed.append(c)
        print(f"frozen columns rewritten on the second run: {changed or 'none'}")
        if changed:
            bad.append(f"the log rewrote what it had already said: {changed}")

        # 2. outcomes must have advanced
        wa = pd.to_numeric(a["weeks_tracked"], errors="coerce").fillna(0)
        wb = pd.to_numeric(b["weeks_tracked"], errors="coerce").fillna(0)
        grew = int((wb > wa).sum())
        print(f"rows whose tracking advanced: {grew} of {len(common)}")
        if len(common) and grew == 0:
            bad.append("twelve weeks passed and no row gained any tracking")

        # 3. the outcome vocabulary must be closed
        vocab = {"watching", "open", "stopped out", "reached first target",
                 "never triggered"}
        seen = set(second["outcome"].dropna())
        print(f"outcomes seen: {sorted(seen)}")
        if not seen <= vocab:
            bad.append(f"unexpected outcome values: {sorted(seen - vocab)}")

        # 4. a stop can only be recorded after the trigger was reached
        trig = second["triggered"].astype(str).str.lower() == "true"
        stopped = second["stopped"].astype(str).str.lower() == "true"
        if int((stopped & ~trig).sum()):
            bad.append("a signal was recorded as stopped out without ever triggering")
        print(f"triggered {int(trig.sum())}, stopped {int(stopped.sum())}, "
              f"consistent: {not int((stopped & ~trig).sum())}")

        # 5. the summary must read back
        s = J.summarise(logp)
        print(f"summary rows: {len(s)}")
        if s.empty and len(second):
            bad.append("summarise returned nothing for a non-empty log")
    finally:
        J.SIGNALS = orig
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n" + ("FAILURES:\n  " + "\n  ".join(bad) if bad else "JOURNAL IS A RECORD, NOT AN OPINION"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
