"""
One sector taxonomy, because three of them is the same as none.

The problem
-----------
Sector labels now arrive from three sources that do not agree on what a sector
is called, or on how many there are:

    Wikipedia, US       GICS sectors, 11 of them   "Information Technology"
    Wikipedia, UK       ICB supersectors, 20       "Industrial Goods and Services"
    Yahoo, everything   its own scheme, 11         "Technology"

Composites are keyed on the sector string. Left unreconciled, Apple labelled
"Information Technology" by Wikipedia and a Trading 212 addition labelled
"Technology" by Yahoo form two separate composites for the same sector. Both are
thinner than the real group, both fall below the five-member minimum more often,
and a stock gets measured against half its peers while the dashboard shows a
sector relative strength that looks perfectly reasonable. Nothing errors. The
group factor simply becomes noise.

This is the failure mode that matters most as the universe widens, because the
broker list is the part with no sector at all and the part that will soon be
most of the universe.

The choice made here
--------------------
Everything is mapped onto the eleven GICS sectors, because that is the only
resolution all three sources can express. ICB's twenty supersectors are richer,
and collapsing Banks and Insurance into Financials genuinely loses information
that Weinstein would have used: he thinks in narrower groups than these.

The trade is taken anyway, for a reason that is not aesthetic. A granular group
with four members is not a group, it is four stocks, and the composite for it
does not get built at all. Before this reconciliation the live scan was
producing eleven composites for a universe of over twelve hundred names, and
every UK line in the dashboard showed a dash in its sector columns, which means
Weinstein's group precondition was not being tested on any of them. A slightly
coarse group that exists beats an ideal group that does not.

Unrecognised labels are kept, not discarded
-------------------------------------------
A label this module does not know is passed through unchanged and reported in
the run log. Silently mapping it to the nearest-looking bucket would corrupt a
composite with a company that does not belong in it, and silently dropping it
would remove a stock's group with no trace of why. Passing it through means it
forms its own bucket, which will usually fail the member minimum and leave a
neutral group factor: the correct outcome for "we do not know what this is".
"""

from __future__ import annotations

#: The eleven GICS sectors, used as the canonical set.
CANONICAL = [
    "Communication Services", "Consumer Discretionary", "Consumer Staples",
    "Energy", "Financials", "Health Care", "Industrials",
    "Information Technology", "Materials", "Real Estate", "Utilities",
]

#: Everything the three sources actually emit, mapped onto the canonical set.
#: Keys are matched after lowercasing and stripping punctuation, so
#: "Food, Beverage and Tobacco" and "Food Beverage & Tobacco" both hit.
_ALIASES = {
    # --- already canonical -------------------------------------------------
    "communication services": "Communication Services",
    "consumer discretionary": "Consumer Discretionary",
    "consumer staples": "Consumer Staples",
    "energy": "Energy",
    "financials": "Financials",
    "health care": "Health Care",
    "industrials": "Industrials",
    "information technology": "Information Technology",
    "materials": "Materials",
    "real estate": "Real Estate",
    "utilities": "Utilities",

    # --- Yahoo -------------------------------------------------------------
    "technology": "Information Technology",
    "financial services": "Financials",
    "healthcare": "Health Care",
    "consumer cyclical": "Consumer Discretionary",
    "consumer defensive": "Consumer Staples",
    "basic materials": "Materials",
    "industrial goods": "Industrials",
    "services": "Industrials",
    "conglomerates": "Industrials",

    # --- ICB supersectors, the FTSE pages ----------------------------------
    "banks": "Financials",
    "insurance": "Financials",
    "life insurance": "Financials",
    "nonlife insurance": "Financials",
    "non life insurance": "Financials",
    "investment banking and brokerage services": "Financials",
    "finance and credit services": "Financials",
    "closed end investments": "Financials",
    "open end and miscellaneous investment vehicles": "Financials",
    "equity investment instruments": "Financials",
    "telecommunications": "Communication Services",
    "media": "Communication Services",
    "telecommunications equipment": "Communication Services",
    "telecommunications service providers": "Communication Services",
    "automobiles and parts": "Consumer Discretionary",
    "retail": "Consumer Discretionary",
    "retailers": "Consumer Discretionary",
    "travel and leisure": "Consumer Discretionary",
    "consumer products and services": "Consumer Discretionary",
    "household goods and home construction": "Consumer Discretionary",
    "leisure goods": "Consumer Discretionary",
    "personal goods": "Consumer Discretionary",
    "food beverage and tobacco": "Consumer Staples",
    "food and beverage": "Consumer Staples",
    "beverages": "Consumer Staples",
    "tobacco": "Consumer Staples",
    "food producers": "Consumer Staples",
    "personal care drug and grocery stores": "Consumer Staples",
    "food and drug retailers": "Consumer Staples",
    "industrial goods and services": "Industrials",
    "construction and materials": "Industrials",
    "aerospace and defence": "Industrials",
    "aerospace and defense": "Industrials",
    "general industrials": "Industrials",
    "electronic and electrical equipment": "Industrials",
    "industrial engineering": "Industrials",
    "industrial transportation": "Industrials",
    "industrial support services": "Industrials",
    "support services": "Industrials",
    "basic resources": "Materials",
    "chemicals": "Materials",
    "industrial metals and mining": "Materials",
    "precious metals and mining": "Materials",
    "mining": "Materials",
    "forestry and paper": "Materials",
    "oil gas and coal": "Energy",
    "oil and gas": "Energy",
    "oil and gas producers": "Energy",
    "alternative energy": "Energy",
    "electricity": "Utilities",
    "gas water and multi utilities": "Utilities",
    "waste and disposal services": "Utilities",
    "health care providers": "Health Care",
    "pharmaceuticals and biotechnology": "Health Care",
    "medical equipment and services": "Health Care",
    "software and computer services": "Information Technology",
    "technology hardware and equipment": "Information Technology",
    "real estate investment trusts": "Real Estate",
    "real estate investment and services": "Real Estate",
}

_DROP = str.maketrans({c: " " for c in ",&/()-.'’"})

#: "Aerospace & Defence", "Aerospace and Defence" and "Aerospace Defence" are
#: the same supersector written three ways, and every source picks a different
#: one. Dropping the conjunction entirely is what makes the alias table match
#: all three from a single entry.
_NOISE = {"and", "the", "of"}


def _key(label: str) -> str:
    words = str(label or "").translate(_DROP).lower().split()
    return " ".join(w for w in words if w not in _NOISE)


#: The alias table is written in readable English, but lookups happen on the
#: stripped key, so the keys are put through the same function at import. Doing
#: this by hand in the table above would mean every future entry has to remember
#: a convention, and the one that forgot would fail silently as a missing sector.
_LOOKUP = {_key(k): v for k, v in _ALIASES.items()}


def canonical(label: str) -> str:
    """
    The canonical sector for a label from any of the three sources.

    Returns "" for an empty label, the canonical name for a recognised one, and
    the original string unchanged for anything else, so an unknown label is
    visible rather than silently rebucketed or silently dropped.
    """
    k = _key(label)
    if not k:
        return ""
    return _LOOKUP.get(k, str(label).strip())


def is_known(label: str) -> bool:
    return _key(label) in _LOOKUP


def normalise_frame(uni, column: str = "sector", verbose: bool = True):
    """
    Canonicalises a universe frame's sector column in place on a copy, and
    reports what it could not recognise. The report is the point: an unknown
    label is a one-line fix to the alias table above, but only if someone can
    see that it happened.
    """
    uni = uni.copy()
    if column not in uni.columns:
        return uni
    raw = uni[column].astype(str)
    uni[column] = raw.map(canonical)

    if verbose:
        unknown = sorted({s for s in raw
                          if str(s).strip() and str(s).strip().lower() not in ("nan", "none")
                          and not is_known(s)})
        blank = int((uni[column].astype(str).str.strip() == "").sum())
        got = sorted(set(uni[column]) & set(CANONICAL))
        print(f"  sectors: {len(got)} of {len(CANONICAL)} canonical groups present,"
              f" {blank} name(s) with no sector at all")
        if unknown:
            shown = ", ".join(unknown[:8])
            print(f"  sectors: {len(unknown)} label(s) not in the alias table"
                  f" and left as they are: {shown}"
                  + (" ..." if len(unknown) > 8 else ""))
    return uni
