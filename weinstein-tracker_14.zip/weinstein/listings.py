"""
Whole-market symbol lists, for the names no index covers.

The index scrapes give about 1,250 names because that is what the S&P 500, S&P
400 and FTSE 350 contain. Everything smaller is invisible to them by
construction. This module goes to the exchanges' own published symbol
directories instead.

US: the NASDAQ Trader symbol directory
--------------------------------------
`nasdaqtraded.txt` is a pipe-delimited file published daily covering every
symbol traded on every US venue, not only NASDAQ, at roughly twelve thousand
rows. It needs no key and no scraping. Its header is:

    Nasdaq Traded|Symbol|Security Name|Listing Exchange|Market Category|ETF|
    Round Lot Size|Test Issue|Financial Status|CQS Symbol|NASDAQ Symbol|NextShares

The filtering matters more than the fetching. Twelve thousand rows is not twelve
thousand companies: it is companies plus ETFs, warrants, units, rights,
preferred lines, depositary shares, trust units and test issues. Warrants and
units in particular are the reason a naive whole-market scan produces beautiful
breakouts on instruments that expire. They are excluded on the security NAME
rather than on a symbol suffix, because suffix conventions differ by venue and
a fifth-letter rule silently drops real companies.

UK: there is no equivalent, and that is the honest answer
--------------------------------------------------------
The London Stock Exchange publishes no comparable free flat file, and AIM has no
usable free constituent list. The FTSE SmallCap and Fledgling pages add roughly
two hundred names on top of the FTSE 350 and that is where free UK coverage
stops. The Trading 212 instruments endpoint is the only route to the full UK
list, which is why that key is worth setting up: for US breadth it is a
convenience, for UK breadth it is the whole thing.

Everything here degrades
------------------------
Every function returns an empty frame on any failure and says so. A symbol
directory that moves, changes format or goes down must cost you the extra names,
never the scan.

A caveat I cannot remove
------------------------
This module talks to an external file I cannot reach from where it was written.
The header above was verified against the live file, but the parsing, the
filtering and the failure paths were tested only against fixtures. It is the
least-verified code in this project, which is exactly why it is built to fail
into "no extra names" rather than into a wrong universe.
"""

from __future__ import annotations

import io

import pandas as pd
import requests

NASDAQ_TRADED = "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqtraded.txt"
OTHER_LISTED = "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt"
UA = {"User-Agent": "Mozilla/5.0 (weinstein-tracker; personal research)"}
TIMEOUT = 60

#: Security-name fragments that mark an instrument this system does not model.
#: Weinstein stage analysis assumes an ongoing equity with a real float; a
#: warrant has an expiry, a unit is a bundle, and a preferred line trades on
#: yield rather than on the business.
_NOT_A_COMPANY = (
    " warrant", " warrants", " unit", " units", " right", " rights",
    " preferred", " preference", " depositary", " depository",
    " when issued", " when-issued", " notes due", " subordinated",
    " convertible note", " trust preferred", "% pfd", " pfd",
    " contingent value", " escrow", " liquidating",
)

#: NASDAQ financial-status codes worth excluding outright. D and E are listing
#: deficiencies and Q is bankruptcy: a breakout on a company in Chapter 11 is a
#: chart pattern attached to a legal process.
_BAD_STATUS = {"D", "E", "Q"}


def _looks_like_company(name: str) -> bool:
    low = f" {str(name or '').lower()} "
    return not any(frag in low for frag in _NOT_A_COMPANY)


def _clean_symbol(sym: str) -> str:
    """NASDAQ writes share classes as BRK.A; Yahoo wants BRK-A."""
    return str(sym or "").strip().upper().replace(".", "-").replace("$", "-")


def _valid_symbol(sym: str) -> bool:
    s = str(sym or "").strip()
    if not s or len(s) > 6:
        return False
    return all(c.isalnum() or c in "-" for c in s)


def parse_nasdaq_traded(text: str, include_etfs: bool = False) -> pd.DataFrame:
    """
    Parses the symbol directory text into ticker/name rows.

    Split out from the fetch so the filtering can be tested without a network,
    which is the only part of this module that can be tested at all.
    """
    if not text or "|" not in text:
        return pd.DataFrame(columns=["ticker", "name"])
    # The file ends with a "File Creation Time" line that is not a record.
    lines = [ln for ln in text.splitlines()
             if "|" in ln and not ln.lower().startswith("file creation time")]
    if len(lines) < 2:
        return pd.DataFrame(columns=["ticker", "name"])

    df = pd.read_csv(io.StringIO("\n".join(lines)), sep="|", dtype=str,
                     keep_default_na=False)
    cols = {c.strip().lower(): c for c in df.columns}
    sym_c = cols.get("symbol") or cols.get("act symbol") or cols.get("nasdaq symbol")
    nam_c = cols.get("security name")
    if not sym_c or not nam_c:
        return pd.DataFrame(columns=["ticker", "name"])

    keep = pd.Series(True, index=df.index)
    if cols.get("test issue"):
        keep &= df[cols["test issue"]].str.strip().str.upper() != "Y"
    if cols.get("nextshares"):
        keep &= df[cols["nextshares"]].str.strip().str.upper() != "Y"
    if cols.get("etf") and not include_etfs:
        keep &= df[cols["etf"]].str.strip().str.upper() != "Y"
    if cols.get("financial status"):
        keep &= ~df[cols["financial status"]].str.strip().str.upper().isin(_BAD_STATUS)

    df = df[keep].copy()
    df["ticker"] = df[sym_c].map(_clean_symbol)
    df["name"] = df[nam_c].str.strip()
    df = df[df["name"].map(_looks_like_company)]
    df = df[df["ticker"].map(_valid_symbol)]
    return (df[["ticker", "name"]]
            .drop_duplicates(subset=["ticker"])
            .sort_values("ticker")
            .reset_index(drop=True))


def us_symbols(include_etfs: bool = False, verbose: bool = True) -> pd.DataFrame:
    """
    Every ordinary US common stock the exchanges publish. Empty frame on any
    failure, with the reason printed.
    """
    for url in (NASDAQ_TRADED, OTHER_LISTED):
        try:
            r = requests.get(url, headers=UA, timeout=TIMEOUT)
            r.raise_for_status()
            out = parse_nasdaq_traded(r.text, include_etfs=include_etfs)
            if not out.empty:
                if verbose:
                    print(f"  US symbol directory: {len(out)} company lines"
                          f" from {url.rsplit('/', 1)[-1]}")
                out["market"] = "US"
                out["sector"] = ""
                out["index"] = "USALL"
                return out
            if verbose:
                print(f"  {url.rsplit('/', 1)[-1]} parsed to nothing, trying the next source")
        except Exception as e:                           # noqa: BLE001
            if verbose:
                print(f"  US symbol directory {url.rsplit('/', 1)[-1]} failed: {e}")
    if verbose:
        print("  ::warning:: no US symbol directory available, "
              "the universe keeps its index names only")
    return pd.DataFrame(columns=["ticker", "name", "market", "sector", "index"])
