"""
Corporate event dates, and what they do to a breakout.

Why this module exists
----------------------
Three consecutive single-ticker pre-trade audits on this system (DGX, MGAM.L,
GFRD.L) found the same thing: the breakout week was a results-day reaction. The
volume test passed on the arithmetic and failed on its intent. Weinstein's 2x
volume rule is a proxy for institutional accumulation building over weeks; a
one-day gap on an earnings beat clears the same bar in a single session while
meaning something quite different, and the move it produces is the reaction to
one number rather than the start of an advance.

A weekly OHLCV scan cannot see this. It sees a big green bar on heavy volume,
which is exactly what it was built to look for.

What this module does NOT claim
-------------------------------
It does not assert that event-driven breakouts fail more often. Three cases is
an anecdote, not a base rate, and pretending otherwise would be the same sin as
the readiness decile table that passed at 28.7 sigma on pure noise. What it does
is mark them, cap the grade so they cannot sort to the top unexamined, and write
the flag into the journal's frozen columns so that after a few months of forward
data the question can be answered from the record rather than from my priors.

The grade cap is justified on mechanism and on Weinstein's own text, where not
buying into a news spike is an explicit instruction, not a statistical claim.

Missing data is never a pass
----------------------------
Coverage of results dates is patchy, especially for UK small caps. An unknown
event date is reported as "unknown" and shown, not silently treated as "clear".
That is the same rule the rest of the scoring layer follows.

Purity
------
Nothing here is called from the scoring layer. Scoring stays deterministic and
offline-testable; events are fetched once for the shortlist that already has a
signal and applied afterwards, in scan.py. Fetching per-ticker event data for
the whole universe would be thousands of requests, and would be wasted on the
90% of rows that have no signal to qualify.
"""

from __future__ import annotations

import os
import time
import datetime as dt

import pandas as pd

# An event this far ahead of the as-of date turns a chart trade into an event
# bet for anyone holding through it.
EVENT_AHEAD_DAYS = 28

# An event this close to the signal week means the break is the reaction to the
# event rather than an independent move. Twelve days covers the signal week
# itself plus the week before it: a gap on the Wednesday often does not confirm
# a breakout until the following week's close, which is precisely what happened
# on GFRD.L, where the 15 July trading statement produced a signal stamped
# 20 July.
EVENT_NEAR_DAYS = 12

CACHE_DIR = os.environ.get("WEINSTEIN_CACHE", "cache")
EVENT_CACHE = os.path.join(CACHE_DIR, "events.csv")
CACHE_MAX_AGE_DAYS = 5      # shorter than a week, so a weekly run always refreshes

STATUS_CLEAR = "clear"
STATUS_AHEAD = "event_ahead"
STATUS_DRIVEN = "event_driven"
STATUS_BOTH = "event_driven_and_ahead"
STATUS_UNKNOWN = "unknown"
STATUS_NA = "not_applicable"      # crypto and anything else without results dates


# --------------------------------------------------------------------------
# fetching
# --------------------------------------------------------------------------
def _dates_for(yf, ticker: str) -> list[dt.date] | None:
    """
    Returns event dates for one ticker, or None if the lookup failed outright.
    An empty list means "looked, found nothing", which is different from None
    and is treated differently downstream.
    """
    found: list[dt.date] = []
    ok = False

    try:
        t = yf.Ticker(ticker)
    except Exception:                                    # noqa: BLE001
        return None

    # Preferred: the earnings-dates table, which carries past and future rows.
    try:
        df = t.get_earnings_dates(limit=12)
        if df is not None and len(df):
            ok = True
            for ts in df.index:
                try:
                    found.append(pd.Timestamp(ts).date())
                except Exception:                        # noqa: BLE001
                    continue
    except Exception:                                    # noqa: BLE001
        pass

    # Fallback: the calendar, which usually has only the next date but covers
    # some listings the table above does not, including many UK lines.
    try:
        cal = t.calendar
        raw = []
        if isinstance(cal, dict):
            raw = cal.get("Earnings Date") or cal.get("earningsDate") or []
        elif isinstance(cal, pd.DataFrame) and "Earnings Date" in cal.index:
            raw = list(cal.loc["Earnings Date"].dropna().values)
        if not isinstance(raw, (list, tuple)):
            raw = [raw]
        for v in raw:
            try:
                found.append(pd.Timestamp(v).date())
                ok = True
            except Exception:                            # noqa: BLE001
                continue
    except Exception:                                    # noqa: BLE001
        pass

    if not ok:
        return None
    return sorted(set(found))


def fetch(tickers: list[str], asof: dt.date | None = None,
          pause: float = 0.35, cache_path: str | None = None,
          verbose: bool = True) -> dict[str, list[dt.date] | None]:
    """
    Event dates for a shortlist of tickers, cached to disk between runs.

    Returns {ticker: [dates] or None}. None means the lookup failed and the
    caller must report "unknown" rather than assuming a clear diary.
    """
    asof = asof or dt.date.today()
    path = cache_path or EVENT_CACHE
    cached: dict[str, list[dt.date] | None] = {}
    fresh_on: dict[str, dt.date] = {}

    if os.path.exists(path):
        try:
            cdf = pd.read_csv(path)
            for _, r in cdf.iterrows():
                t = str(r.get("ticker") or "").strip()
                if not t:
                    continue
                try:
                    got = pd.Timestamp(r.get("fetched_on")).date()
                except Exception:                        # noqa: BLE001
                    continue
                raw = str(r.get("dates") or "").strip()
                if raw == "FAILED":
                    cached[t] = None
                else:
                    ds = []
                    for part in raw.split("|"):
                        part = part.strip()
                        if not part:
                            continue
                        try:
                            ds.append(pd.Timestamp(part).date())
                        except Exception:                # noqa: BLE001
                            continue
                    cached[t] = ds
                fresh_on[t] = got
        except Exception as e:                           # noqa: BLE001
            if verbose:
                print(f"  event cache unreadable, refetching: {e}")

    stale = [t for t in tickers
             if t not in fresh_on
             or (asof - fresh_on[t]).days > CACHE_MAX_AGE_DAYS]

    out: dict[str, list[dt.date] | None] = {t: cached.get(t) for t in tickers
                                            if t in cached}

    if stale:
        try:
            import yfinance as yf
        except ImportError:
            if verbose:
                print("  yfinance unavailable, event dates will read as unknown")
            for t in stale:
                out.setdefault(t, None)
            return {t: out.get(t) for t in tickers}

        if verbose:
            print(f"  fetching event dates for {len(stale)} candidate(s)"
                  f" ({len(tickers) - len(stale)} still fresh in cache)")
        failures = 0
        for i, t in enumerate(stale, 1):
            out[t] = _dates_for(yf, t)
            if out[t] is None:
                failures += 1
            if verbose and i % 50 == 0:
                print(f"    {i} of {len(stale)}")
            time.sleep(pause)
        if verbose:
            print(f"  event dates: {len(stale) - failures} resolved,"
                  f" {failures} unavailable")

        # Persist everything we now know, not just this run's shortlist, so the
        # cache accumulates instead of being rewritten down to one week's names.
        merged = dict(cached)
        merged.update({t: out[t] for t in stale})
        merged_on = dict(fresh_on)
        for t in stale:
            merged_on[t] = asof
        _save(merged, merged_on, path)

    return {t: out.get(t) for t in tickers}


def _save(data: dict[str, list[dt.date] | None],
          fetched_on: dict[str, dt.date], path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    rows = []
    for t, ds in data.items():
        rows.append({
            "ticker": t,
            "fetched_on": fetched_on.get(t, dt.date.today()).isoformat(),
            "dates": "FAILED" if ds is None else "|".join(d.isoformat() for d in ds),
        })
    pd.DataFrame(rows).sort_values("ticker").to_csv(path, index=False)


# --------------------------------------------------------------------------
# classification
# --------------------------------------------------------------------------
def classify(dates: list[dt.date] | None, asof: dt.date,
             signal_date: dt.date | None = None,
             applicable: bool = True) -> dict:
    """
    Turns a list of event dates into the two facts that change a decision:
    is there an event close enough ahead to be holding through it, and did the
    signal itself fire on the back of one.
    """
    if not applicable:
        return {"event_status": STATUS_NA, "next_event": None,
                "days_to_event": None, "event_near_signal": None,
                "event_note": ""}

    if dates is None:
        return {"event_status": STATUS_UNKNOWN, "next_event": None,
                "days_to_event": None, "event_near_signal": None,
                "event_note": "no results date could be found for this line, so "
                              "the event risk here is unmeasured rather than absent"}

    future = sorted(d for d in dates if d >= asof)
    nxt = future[0] if future else None
    days = (nxt - asof).days if nxt else None
    ahead = days is not None and days <= EVENT_AHEAD_DAYS

    near = None
    if signal_date is not None:
        # The signal week is stamped with its Monday; its trading week ends on
        # the Friday. Measure back from that Friday.
        week_end = signal_date + dt.timedelta(days=(4 - signal_date.weekday()) % 7)
        near = any(0 <= (week_end - d).days <= EVENT_NEAR_DAYS for d in dates)

    if near and ahead:
        status = STATUS_BOTH
    elif near:
        status = STATUS_DRIVEN
    elif ahead:
        status = STATUS_AHEAD
    else:
        status = STATUS_CLEAR

    notes = []
    if near:
        notes.append("the breakout week sits within days of a results or trading "
                     "statement, so the volume that confirmed it is a reaction to "
                     "that news rather than accumulation building over weeks")
    if ahead:
        notes.append(f"results are due in {days} day(s) ({nxt.isoformat()}), inside "
                     "the holding window, which makes this an event bet as well as "
                     "a chart trade")

    return {"event_status": status,
            "next_event": nxt.isoformat() if nxt else None,
            "days_to_event": days,
            "event_near_signal": near,
            "event_note": "; ".join(notes)}


# --------------------------------------------------------------------------
# application
# --------------------------------------------------------------------------
#: Grades an event flag will not let a signal exceed. Unknown is deliberately
#: not capped: penalising a line for thin data coverage would systematically
#: demote UK small caps for a reason that has nothing to do with their charts.
#: It is surfaced as a marker instead, so the reader supplies the judgement.
CAP = {STATUS_DRIVEN: "C", STATUS_BOTH: "C", STATUS_AHEAD: "B"}

_ORDER = {"A": 0, "B": 1, "C": 2, "D": 3}


def apply(rec: dict, info: dict) -> dict:
    """
    Folds an event classification into an already-scored record. Only ever
    lowers a grade; nothing here can promote a signal.
    """
    rec = dict(rec)
    rec.update({k: info.get(k) for k in
                ("event_status", "next_event", "days_to_event", "event_near_signal")})

    sig = rec.get("signal")
    if not isinstance(sig, dict):
        return rec

    sig = dict(sig)
    sig.update({k: info.get(k) for k in
                ("event_status", "next_event", "days_to_event", "event_near_signal")})

    cap = CAP.get(info.get("event_status"))
    if cap:
        cur = sig.get("grade")
        if cur in _ORDER and _ORDER[cap] > _ORDER[cur]:
            sig["grade"] = cap
            sig["notes"] = ((sig.get("notes") or "") + ("; " if sig.get("notes") else "")
                            + f"{info['event_note']}. Graded down to {cap} for that.")
        elif info.get("event_note"):
            sig["notes"] = ((sig.get("notes") or "") + ("; " if sig.get("notes") else "")
                            + info["event_note"] + ".")
    elif info.get("event_note"):
        sig["notes"] = ((sig.get("notes") or "") + ("; " if sig.get("notes") else "")
                        + info["event_note"] + ".")

    rec["signal"] = sig
    rec["grade"] = sig.get("grade")
    return rec


def signal_date_of(rec: dict) -> dt.date | None:
    """The week the signal actually fired, if the record carries one."""
    sig = rec.get("signal")
    if not isinstance(sig, dict):
        return None
    at = sig.get("at_signal")
    raw = (at or {}).get("date") if isinstance(at, dict) else None
    if raw is None:
        # A signal that fired this week carries no at_signal snapshot, because
        # there is nothing to snapshot: the scan week IS the signal week.
        raw = sig.get("date") or rec.get("date")
    if raw is None:
        return None
    try:
        return pd.Timestamp(raw).date()
    except Exception:                                    # noqa: BLE001
        return None
