"""
The Trading 212 instrument list, as a tradeability filter.

Why a filter and not the universe
---------------------------------
It is tempting to throw away the index scrapes and build everything from the
broker's list, since that list is by definition exactly what can be bought. The
reason not to is sector metadata: the T212 instruments endpoint returns ticker,
ISIN, name, type and currency, and no sector at all. Weinstein treats group
strength as a precondition rather than a tiebreak, so a universe with no sector
labels would silently disable the group factor for every name in it and leave
every row scored on a neutral 1.0 that means "no opinion" rather than "fine".

So the index scrapes stay as the source of sector truth, and this module does
two narrower jobs: it marks which of those names are actually buyable on the
account, and it adds the buyable names that no index list covers, accepting that
those arrive without a sector.

The ticker format
-----------------
Trading 212 identifies instruments in its own scheme, and the scheme is not
consistent between markets:

    US listings   MCRB_US_EQ    symbol, then _US_, then the instrument type
    UK listings   BPl_EQ        symbol with a lowercase l glued on, then the type

There is no exchange field. `workingScheduleId` implies one but the table it
refers to is not exposed. So the market has to be inferred, and it is inferred
from three signals rather than one: the ticker shape, the ISIN country prefix,
and the currency code. Where they disagree the instrument is skipped, because a
UK line mapped to a US symbol does not fail loudly, it silently downloads a
different company's price history and scores it.

Share classes are where this mapping genuinely cannot win. Yahoo wants BT-A.L
and BRK-B; T212 gives something like BTAl_EQ with the separator already gone, so
the class boundary is unrecoverable from the string. Those names resolve wrongly
or not at all, which is why the ticker is verified against downloaded price data
downstream and dropped when no series comes back, and why index-derived symbols
always win over broker-derived ones when both describe the same company.
"""

from __future__ import annotations

import os
import re

import pandas as pd
import requests

API_URL = "https://live.trading212.com/api/v0/equity/metadata/instruments"
DEMO_URL = "https://demo.trading212.com/api/v0/equity/metadata/instruments"
CACHE_DIR = os.environ.get("WEINSTEIN_CACHE", "cache")
CACHE = os.path.join(CACHE_DIR, "t212_instruments.csv")
KEY_ENV = "T212_API_KEY"

TIMEOUT = 60

# Instrument types worth scanning. Everything else T212 lists (futures-style
# CFDs and so on) is outside what this system models.
EQUITY_TYPES = {"STOCK", "EQUITY", "ETF"}
CRYPTO_TYPES = {"CRYPTOCURRENCY", "CRYPTO"}

_US_RE = re.compile(r"^(?P<sym>[A-Za-z0-9.\-]+)_US_(?P<type>[A-Z]+)$")
_UK_RE = re.compile(r"^(?P<sym>[A-Za-z0-9.\-]*[A-Za-z0-9])l_(?P<type>[A-Z]+)$")


def fetch_instruments(api_key: str | None = None, demo: bool = False,
                      use_cache_on_failure: bool = True) -> pd.DataFrame:
    """
    The raw instrument list. Falls back to the cached copy on any failure, so a
    broker outage or an expired key degrades the universe to "last known
    tradeable list" instead of emptying it.
    """
    api_key = api_key or os.environ.get(KEY_ENV, "").strip()
    if not api_key:
        if use_cache_on_failure and os.path.exists(CACHE):
            print("  no Trading 212 key set, using the cached instrument list")
            return pd.read_csv(CACHE)
        print(f"  no Trading 212 key set (${KEY_ENV}), tradeability will not be checked")
        return pd.DataFrame()

    url = DEMO_URL if demo else API_URL
    try:
        r = requests.get(url, headers={"Authorization": api_key}, timeout=TIMEOUT)
        r.raise_for_status()
        rows = r.json()
        df = pd.DataFrame(rows)
        if df.empty:
            raise ValueError("empty instrument list")
        os.makedirs(CACHE_DIR, exist_ok=True)
        df.to_csv(CACHE, index=False)
        print(f"  Trading 212: {len(df)} instruments listed")
        return df
    except Exception as e:                            # noqa: BLE001
        print(f"  Trading 212 instrument fetch failed: {e}")
        if use_cache_on_failure and os.path.exists(CACHE):
            print("  falling back to the cached instrument list")
            return pd.read_csv(CACHE)
        return pd.DataFrame()


def _country(isin: str) -> str:
    s = str(isin or "").strip().upper()
    return s[:2] if len(s) >= 2 and s[:2].isalpha() else ""


def parse_ticker(t212_ticker: str, isin: str = "", currency: str = "") -> tuple[str, str] | None:
    """
    (yahoo_symbol, market) or None when the instrument is not one this system
    covers, or when the three signals disagree about which market it is on.
    """
    raw = str(t212_ticker or "").strip()
    if not raw:
        return None
    cur = str(currency or "").strip().upper()
    ctry = _country(isin)

    m = _US_RE.match(raw)
    if m:
        # A US-shaped ticker priced in sterling is not a US line, it is a
        # mismatch, and following the shape would download the wrong company.
        if cur and cur not in ("USD", ""):
            return None
        sym = m.group("sym").upper().replace(".", "-")
        return (sym, "US") if sym else None

    m = _UK_RE.match(raw)
    if m:
        if cur and cur not in ("GBP", "GBX", "GBp", ""):
            return None
        if ctry and ctry not in ("GB", "JE", "GG", "IM", "IE"):
            # Depositary lines and foreign issuers quoted in London exist, but a
            # US-domiciled ISIN behind a London-shaped ticker is more often a
            # parse accident than a real dual listing.
            return None
        sym = m.group("sym").upper().replace(".", "-")
        return (f"{sym}.L", "UK") if sym else None

    return None


def tradeable_frame(raw: pd.DataFrame) -> pd.DataFrame:
    """
    Maps the instrument list to Yahoo symbols. Returns ticker, market, name,
    t212_ticker, isin, kind — where kind is 'equity' or 'crypto'.
    """
    if raw is None or raw.empty:
        return pd.DataFrame(columns=["ticker", "market", "name",
                                     "t212_ticker", "isin", "kind"])

    cols = {c.lower(): c for c in raw.columns}
    tcol = cols.get("ticker")
    if not tcol:
        return pd.DataFrame(columns=["ticker", "market", "name",
                                     "t212_ticker", "isin", "kind"])
    ncol = cols.get("name") or cols.get("shortname")
    icol = cols.get("isin")
    ccol = cols.get("currencycode") or cols.get("currency")
    ycol = cols.get("type")

    out = []
    for _, r in raw.iterrows():
        typ = str(r.get(ycol, "") if ycol else "").strip().upper()
        if typ in CRYPTO_TYPES:
            continue                       # the crypto board builds its own list
        if ycol and typ and typ not in EQUITY_TYPES:
            continue
        parsed = parse_ticker(r.get(tcol),
                              r.get(icol, "") if icol else "",
                              r.get(ccol, "") if ccol else "")
        if not parsed:
            continue
        sym, market = parsed
        out.append({"ticker": sym, "market": market,
                    "name": str(r.get(ncol, "") if ncol else "").strip(),
                    "t212_ticker": str(r.get(tcol)),
                    "isin": str(r.get(icol, "") if icol else ""),
                    "kind": "equity"})

    df = pd.DataFrame(out)
    if df.empty:
        return df
    return df.drop_duplicates(subset=["ticker"]).reset_index(drop=True)


def apply_to_universe(uni: pd.DataFrame, tradeable: pd.DataFrame,
                      restrict: bool = True, extend: bool = True,
                      extend_index: str = "T212") -> pd.DataFrame:
    """
    Marks and optionally trims the index-derived universe against what the
    broker actually offers, then adds the tradeable names no index covers.

    An empty tradeable frame is treated as "unknown", not as "nothing is
    tradeable": a failed broker call must not silently empty the scan.
    """
    uni = uni.copy()
    if tradeable is None or tradeable.empty:
        uni["tradeable"] = pd.NA
        return uni

    buyable = set(tradeable["ticker"])
    uni["tradeable"] = uni["ticker"].isin(buyable)

    if restrict:
        before = len(uni)
        uni = uni[uni["tradeable"]].copy()
        print(f"  tradeable filter: kept {len(uni)} of {before} index names")

    if extend:
        # Index rows win on any collision, because they carry the sector label
        # and the broker rows do not.
        known = set(uni["ticker"])
        add = tradeable[~tradeable["ticker"].isin(known)].copy()
        if not add.empty:
            add["sector"] = ""
            add["index"] = extend_index
            add["tradeable"] = True
            uni = pd.concat(
                [uni, add[["ticker", "name", "sector", "market", "index", "tradeable"]]],
                ignore_index=True)
            print(f"  tradeable filter: added {len(add)} name(s) no index list covers")

    return uni.drop_duplicates(subset=["ticker"]).reset_index(drop=True)
