"""
The crypto board.

Weinstein's method is about the shape of a chart, and a chart is a chart. The
30 week average, the base, the breakout, relative strength against the asset
class: all of it transfers. What does not transfer is my thresholds.

Every percentage constant in stages.py was chosen against equity volatility.
A twelve per cent extension above the 30 week line is a stretched equity and an
ordinary Tuesday in crypto. A forty five per cent base width means "this is not
a base, it is a downtrend" for a listed company and describes a perfectly normal
consolidation for a coin. Feed crypto through unchanged and every name reads as
extended, every base reads as invalid, and the scores saturate at the ends of
their ranges where they carry no information.

How this is handled
-------------------
Not by forking the scoring code. The row scorers and their vectorised twins are
kept in lockstep by an exhaustive equivalence test, and duplicating them for a
second asset class would double the surface that test has to cover while
doubling the chance of the two drifting apart. That is the mistake that put an
unassigned branch in the group factor the first time.

Instead the inputs are rescaled into equity-equivalent units before scoring.
Every percentage-denominated feature that a threshold is compared against is
divided by a single volatility scalar, the scoring code runs untouched, and the
displayed numbers are the real ones. A coin twenty seven per cent above its 30
week line with a scalar of 3.0 is scored as an equity nine per cent above its
own, which is the honest comparison.

The scalar is measured, not assumed
-----------------------------------
It is the median weekly ATR across the board divided by a stated equity
reference. Hardcoding 3.0 would be a number that was right on the day it was
typed and silently wrong through the next regime, and it would be doing the
quiet work of an entire calibration while looking like a constant.

What is deliberately not modelled
---------------------------------
There is no sector layer. Crypto sector taxonomies exist but no free source
gives point-in-time membership, and inventing one would produce a group factor
that looks like the equity board's and means nothing. The group factor is left
at a neutral 1.0, which the scoring layer already reads as "no opinion".

There are no earnings, so the event filter reports not-applicable rather than
clear, and does not silently hand every coin a pass the equity board has to earn.
"""

from __future__ import annotations

import datetime as dt

import numpy as np
import pandas as pd

from . import data as D
from . import features as F
from . import market as M
from . import plan as PL
from . import sectors as SEC
from . import stages as S
from . import explain as EX
from . import precheck as PC

#: Yahoo symbols. Trading 212's crypto range is small and changes; this is the
#: liquid core of it and is meant to be edited rather than treated as fixed.
COINS = [
    "BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD", "ADA-USD", "DOGE-USD",
    "AVAX-USD", "DOT-USD", "LINK-USD", "LTC-USD", "BCH-USD", "XLM-USD",
    "UNI-USD", "ATOM-USD", "ETC-USD", "FIL-USD", "AAVE-USD", "ALGO-USD",
    "NEAR-USD", "ICP-USD", "APT-USD", "ARB-USD", "OP-USD", "INJ-USD",
    "SHIB-USD", "TRX-USD", "TON11419-USD", "HBAR-USD", "VET-USD", "SUI20947-USD",
]

#: Median weekly ATR of the equity universe, as a percentage of price. The
#: denominator of the volatility scalar and therefore the definition of one
#: "equity-equivalent" unit. Measured from the FTSE/S&P universe this system
#: already scans rather than taken from a textbook.
EQUITY_REF_ATR_PCT = 4.0

#: Bounds on the scalar. Below 1.0 crypto would be scored as calmer than
#: equities, which is not a state worth modelling, and an unbounded scalar lets
#: one bad ATR reading rescale the whole board.
SCALE_MIN, SCALE_MAX = 1.0, 6.0

#: Percentage features compared against a fixed threshold somewhere in the
#: scoring layer. Anything not on this list is either already unitless (ratios,
#: counts, scores) or is never threshold-compared.
SCALED = [
    "px_vs_ma_pct", "ma_slope_pct", "ma_slope_norm", "ma_slope_delta",
    "base_width_pct", "atr_pct", "atr_vs_ma", "tightness",
    "dist_to_resistance_pct", "dist_to_support_pct",
    "stop_risk_pct", "ret_13w_pct", "ret_52w_pct", "prior_trend_pct",
    "mansfield_rs", "rs_slope", "rs_vs_sector",
]

#: A crypto stop cannot be an equity stop. Twelve per cent is inside the weekly
#: noise of most coins, so a stop there is not protection, it is a guarantee of
#: being taken out by an ordinary week and then watching the move happen.
CRYPTO_PLAN = PL.PlanConfig(
    max_stop_pct=30.0,       # 12% is inside one ordinary week for most coins
    max_t1_move_pct=200.0,   # a 60% cap would truncate almost every base count
    far_trigger_pct=15.0,    # a trigger 8% away is close, not far, at this volatility
    min_buffer_pct=1.2,      # the entry buffer has to clear the noise it sits in
)

MIN_CONSTITUENTS = 5


def drop_partial_week(df: pd.DataFrame, asof: dt.date | None = None) -> pd.DataFrame:
    """
    Crypto trades every day, so its weekly bar closes on Sunday, not Friday.

    Using the equity rule here would keep a bar that still has two days of
    trading left in it: Saturday and Sunday would land in a "finished" week,
    with a truncated volume figure feeding the 2x breakout test and a close that
    is not a weekly close. This is the same class of bug as the Friday fix on
    the equity side, in the opposite direction.
    """
    if df.empty:
        return df
    asof = asof or dt.date.today()
    last = df.index[-1]
    last_date = last.date() if hasattr(last, "date") else last
    week_end = last_date + dt.timedelta(days=(6 - last_date.weekday()) % 7)
    if asof <= week_end:
        return df.iloc[:-1]
    return df


def composite(prices: dict[str, pd.DataFrame]) -> pd.Series:
    """
    Equal-weighted crypto market index, chained from cross-sectional mean weekly
    returns, exactly as the sector composites are built.

    This rather than bitcoin is the benchmark, for one reason: measured against
    bitcoin, bitcoin has a relative strength of zero by construction and drops
    out of its own scan. A composite gives every coin including BTC a real
    reading, and asks the question Weinstein's relative strength is actually for,
    which is whether this thing is leading its asset class.
    """
    series = [df["close"].astype(float) for df in prices.values()
              if df is not None and not df.empty and "close" in df]
    if len(series) < MIN_CONSTITUENTS:
        return pd.Series(dtype=float)
    wide = pd.concat(series, axis=1).sort_index()
    rets = wide.pct_change()
    mean_ret = rets.mean(axis=1, skipna=True)
    n_live = rets.notna().sum(axis=1)
    mean_ret = mean_ret.where(n_live >= MIN_CONSTITUENTS)
    comp = 100.0 * (1.0 + mean_ret.fillna(0.0)).cumprod()
    return comp.where(n_live.cummax() >= MIN_CONSTITUENTS).dropna()


def vol_scale(feats: dict[str, pd.DataFrame],
              ref: float | None = None) -> float:
    """
    How many equity volatilities one crypto volatility is worth, measured from
    the board itself. Returns 1.0 when there is nothing to measure, which means
    "no rescaling" rather than a guess.
    """
    # Read at call time, not bound as a default argument. A module constant
    # captured in a signature cannot be overridden by anything -- including the
    # control arm of the test that is supposed to prove this calibration does
    # something -- which makes that test quietly compare a run against itself.
    ref = EQUITY_REF_ATR_PCT if ref is None else ref
    vals = []
    for f in feats.values():
        if "atr_pct" not in f:
            continue
        s = pd.to_numeric(f["atr_pct"], errors="coerce").dropna().tail(52)
        if len(s):
            vals.append(float(s.median()))
    if not vals or ref <= 0:
        return 1.0
    k = float(np.median(vals)) / float(ref)
    if not np.isfinite(k):
        return 1.0
    return float(min(max(k, SCALE_MIN), SCALE_MAX))


def rescale(feat: pd.DataFrame, k: float) -> pd.DataFrame:
    """
    Equity-equivalent copy of a feature frame. Prices, volumes, levels and
    ratios are untouched; only the percentage columns that meet a threshold are
    divided. The original frame is what gets displayed.
    """
    if k is None or not np.isfinite(k) or k <= 0 or abs(k - 1.0) < 1e-9:
        return feat.copy()
    out = feat.copy()
    for c in SCALED:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce") / k
    return out


def run(years: int = 8, coins: list[str] | None = None,
        prices: dict | None = None, plan_cfg: "PL.PlanConfig | None" = None,
        keep_partial: bool = False) -> dict:
    """
    Scores the crypto board. Same verdicts, same grades, its own regime,
    benchmark and volatility calibration.
    """
    coins = coins or COINS
    plan_cfg = plan_cfg or CRYPTO_PLAN or PL.DEFAULT

    if prices is None:
        print("downloading crypto weekly bars")
        px = D.download_weekly(list(coins), years=years)
    else:
        px = {t: df for t, df in prices.items() if t in set(coins)}

    if not keep_partial:
        px = {t: drop_partial_week(df) for t, df in px.items()}
    px = {t: df for t, df in px.items() if df is not None and len(df) >= F.MIN_HISTORY}

    if len(px) < MIN_CONSTITUENTS:
        print(f"  only {len(px)} coin(s) with enough history, crypto board skipped")
        return {"scan": pd.DataFrame(), "market": {}, "asof": pd.NaT,
                "vol_scale": 1.0, "regime_history": pd.DataFrame()}

    bench = composite(px)
    if bench.empty:
        print("  no crypto composite could be built, board skipped")
        return {"scan": pd.DataFrame(), "market": {}, "asof": pd.NaT,
                "vol_scale": 1.0, "regime_history": pd.DataFrame()}

    print(f"  {len(px)} coins, composite benchmark over {len(bench)} weeks")

    raw_feats: dict[str, pd.DataFrame] = {}
    for t, df in px.items():
        try:
            raw_feats[t] = F.compute_features(df, bench)
        except Exception as e:                       # noqa: BLE001
            print(f"  {t}: feature error {e}")

    if not raw_feats:
        return {"scan": pd.DataFrame(), "market": {}, "asof": pd.NaT,
                "vol_scale": 1.0, "regime_history": pd.DataFrame()}

    k = vol_scale(raw_feats)
    print(f"  volatility scalar {k:.2f}x equity, so thresholds are met at"
          f" {k:.1f} times the equity percentage")

    feats, above = {}, []
    for t, raw in raw_feats.items():
        f = rescale(raw, k)
        # No sector layer: a neutral group factor, stated rather than implied.
        f = SEC.attach_to_stock(f, px[t]["close"].astype(float), None, None)
        f["trend_score"] = S.trend_score_series(f)
        f = f.join(S.readiness_series(f))
        above.append((f["close"] > f["ma30"]).astype(float)
                     .where(f["ma30"].notna()).rename(t))
        feats[t] = f

    breadth = M.breadth_from_features(above)
    regime = M.regime_series(bench, breadth)
    regime_now = str(regime["regime"].iloc[-1]) if not regime.empty else "Unknown"
    ok_now = M.market_ok(regime_now)
    print(f"  crypto regime: {regime_now}"
          + (f" (breadth {breadth.iloc[-1]:.0f}% above the 30 week line)"
             if len(breadth) else ""))

    records, coin_errors = [], []
    for t, f in feats.items():
        try:
            rec = S.evaluate(f, t, t.split("-")[0], "CRYPTO", "", market_ok=ok_now)
        except Exception as e:                       # noqa: BLE001
            coin_errors.append(f"{t}: {type(e).__name__}: {e}")
            continue
        if rec is None:
            continue
        rec["index"] = "CRYPTO"
        # Display the real numbers, not the equity-equivalent ones the scoring
        # ran on. Showing a coin as 9% above its 30 week line when it is 27%
        # above would be a lie told by a unit conversion.
        real = raw_feats[t].iloc[-1]
        for c in SCALED:
            if c in real.index:
                v = real.get(c)
                rec[c] = None if pd.isna(v) else float(v)
        rec["vol_scale"] = k
        rec["event_status"] = "not_applicable"
        rec["liquidity_status"] = "ok"

        kind = (rec.get("signal") or {}).get("kind")
        side = ("short" if kind == "stage4_breakdown"
                else "long" if kind == "stage2_breakout"
                else "short" if (rec.get("stage4_readiness") or 0) > (rec.get("stage2_readiness") or 0)
                else "long")
        try:
            # Plans are built on the REAL frame: a stop has to be a real price.
            rec["plan"] = PL.build_plan(raw_feats[t].iloc[-1], plan_cfg, side=side)
        except Exception:                            # noqa: BLE001
            rec["plan"] = None
        records.append(rec)

    asof_str = str(pd.Timestamp(records[0]["date"]).date()) if records else ""
    for rec in records:
        # Plain-English translation and prompt fields are presentation, not
        # scoring. A coin whose narrative cannot be built is still a scored coin,
        # so a failure here costs a paragraph rather than the whole board.
        try:
            rec["explain"] = EX.explain(rec, {"regime": regime_now})
        except Exception as e:                       # noqa: BLE001
            rec["explain"] = None
            coin_errors.append(f"{rec.get('ticker')} explain: {type(e).__name__}: {e}")
        try:
            rec["prompt_vals"] = PC.fields(rec, asof_str, regime_now)
        except Exception as e:                       # noqa: BLE001
            rec["prompt_vals"] = None
            coin_errors.append(f"{rec.get('ticker')} prompt: {type(e).__name__}: {e}")
    scan = pd.DataFrame(records)

    if coin_errors:
        print(f"  {len(coin_errors)} coin-level error(s), board continued:")
        for line in coin_errors[:10]:
            print(f"    {line}")
    print(f"  scored {len(scan)} coins")
    return {"scan": scan, "vol_scale": k,
            "asof": scan["date"].max() if not scan.empty else pd.NaT,
            "market": M.summary(regime, scan),
            "regime_history": regime[["regime_score", "breadth_above_ma"]].dropna().tail(156)}
