"""
The forward log.

Everything the calibration panel reports is contaminated. Index membership is
today's, so the sample is the survivors; the thresholds were chosen on the same
eight years they are tested against; and the backtest enters at Friday's close
while the plan enters at a trigger. Those are not fixable with more code.

A forward log is fixable, and it is the only clean evidence this system will ever
produce. Every week it records what the scanner said, freezing those numbers, and
then tracks what actually happened to each of those names afterwards. The
resulting sample has no survivorship bias because it is written before the
outcome exists, no lookahead for the same reason, and no in-sample fitting
because the rules were fixed before the first row was written.

It will be a small sample for a long time. That is honest rather than a defect:
a weekly method produces about fifty independent episodes a year and no amount of
tickers changes that. In six months it will say something. In two years it will
say something worth acting on.

Two files, both plain CSV so you can open them in anything:

  log/signals.csv    written by the scan. One row per signal, frozen at first
                     sighting, with outcome columns filled in as weeks pass.
  log/decisions.csv  written by you. Which ones you took, which you passed, and
                     why. Without it there is no way to separate a bad method
                     from good rules poorly followed.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

LOG_DIR = "log"
SIGNALS = os.path.join(LOG_DIR, "signals.csv")
DECISIONS = os.path.join(LOG_DIR, "decisions.csv")

TRACK_WEEKS = 26          # how long a signal stays open for outcome tracking
HORIZONS = (4, 13, 26)

# Frozen at first sighting. These must never be recomputed, or the log stops
# being a record of what was said and becomes a record of what is now believed.
FROZEN = ["signal_id", "first_seen", "ticker", "name", "market", "index", "sector",
          "kind", "grade", "status_at_signal", "confirmed", "stage", "trend_score",
          "stage2_readiness", "stage4_readiness", "mansfield_rs", "sector_rs",
          "rs_vs_sector", "group_factor", "regime", "close_at_signal",
          "trigger", "stop", "t1", "t2", "risk_pct", "t1_r", "signal_age_weeks",
          # Frozen so that after a few months of forward data the question
          # "do event-driven breakouts do worse?" can be answered from the
          # record instead of from three anecdotes and a prior.
          "event_status", "days_to_event", "event_near_signal",
          "liquidity_status", "adv_gbp"]

OUTCOME = ["last_seen", "weeks_tracked", "last_close", "high_since", "low_since",
           "triggered", "triggered_on", "stopped", "stopped_on",
           "hit_t1", "hit_t1_on", "r_peak", "r_now", "outcome"] + \
          [f"exc_{h}w" for h in HORIZONS]


def _f(v):
    try:
        f = float(v)
        return None if np.isnan(f) else f
    except (TypeError, ValueError):
        return None


def _row_from(rec: dict, asof: str, regime: str) -> dict | None:
    sig = rec.get("signal") or {}
    kind = sig.get("kind")
    plan = rec.get("plan") or {}
    if not kind or not plan:
        return None
    # The id is the ticker plus the week the signal itself fired, so the same
    # break seen again next week updates its row instead of creating a new one.
    age = int(rec.get("signal_age_weeks") or 0)
    fired = (pd.Timestamp(asof) - pd.Timedelta(weeks=age)).date()
    return {
        "signal_id": f"{rec['ticker']}@{fired}",
        "first_seen": asof, "ticker": rec["ticker"], "name": rec.get("name", ""),
        "market": rec.get("market", ""), "index": rec.get("index", ""),
        "sector": rec.get("sector", ""), "kind": kind,
        "grade": rec.get("grade"), "status_at_signal": sig.get("status"),
        "confirmed": bool(sig.get("confirmed")), "stage": rec.get("stage"),
        "trend_score": _f(rec.get("trend_score")),
        "stage2_readiness": _f(rec.get("stage2_readiness")),
        "stage4_readiness": _f(rec.get("stage4_readiness")),
        "mansfield_rs": _f(rec.get("mansfield_rs")),
        "sector_rs": _f(rec.get("sector_rs")),
        "rs_vs_sector": _f(rec.get("rs_vs_sector")),
        "group_factor": _f(rec.get("group_factor")),
        "regime": regime, "close_at_signal": _f(rec.get("close")),
        "trigger": _f(plan.get("trigger")), "stop": _f(plan.get("stop")),
        "t1": _f(plan.get("t1")), "t2": _f(plan.get("t2")),
        "risk_pct": _f(plan.get("risk_pct")), "t1_r": _f(plan.get("t1_r")),
        "signal_age_weeks": age,
        "event_status": rec.get("event_status"),
        "days_to_event": _f(rec.get("days_to_event")),
        "event_near_signal": rec.get("event_near_signal"),
        "liquidity_status": rec.get("liquidity_status"),
        "adv_gbp": _f(rec.get("adv_gbp")),
    }


def _track(row: pd.Series, feat: pd.DataFrame, bench: pd.Series | None) -> dict:
    """Fill in what has happened to one logged signal since it was first seen."""
    out = {}
    seg = feat.loc[pd.Timestamp(row["first_seen"]):]
    if seg.empty:
        return out
    long = row["kind"] == "stage2_breakout"
    sign = 1.0 if long else -1.0
    hi, lo = seg["high"], seg["low"]
    close = seg["close"]

    out["last_seen"] = str(seg.index[-1].date())
    out["weeks_tracked"] = int(len(seg) - 1)
    out["last_close"] = round(float(close.iloc[-1]), 4)
    out["high_since"] = round(float(hi.max()), 4)
    out["low_since"] = round(float(lo.min()), 4)

    def first_touch(series, level, above):
        if level is None or np.isnan(level):
            return None
        hit = series >= level if above else series <= level
        if not hit.any():
            return None
        return str(series.index[hit.to_numpy().argmax()].date())

    trig, stop, t1 = _f(row["trigger"]), _f(row["stop"]), _f(row["t1"])
    out["triggered_on"] = first_touch(hi if long else lo, trig, long)
    out["triggered"] = out["triggered_on"] is not None
    # A stop only counts once the position would actually exist.
    if out["triggered"] and stop is not None:
        after = seg.loc[pd.Timestamp(out["triggered_on"]):]
        s = after["low"] if long else after["high"]
        out["stopped_on"] = first_touch(s, stop, not long)
    else:
        out["stopped_on"] = None
    out["stopped"] = out["stopped_on"] is not None
    out["hit_t1_on"] = first_touch(hi if long else lo, t1, long) if out["triggered"] else None
    out["hit_t1"] = out["hit_t1_on"] is not None

    risk = abs(trig - stop) if (trig is not None and stop is not None) else None
    if out["triggered"] and risk:
        peak = (float(hi.max()) - trig) if long else (trig - float(lo.min()))
        out["r_peak"] = round(peak / risk, 2)
        out["r_now"] = round((float(close.iloc[-1]) - trig) * sign / risk, 2)

    # Forward excess return against the stock's own benchmark, log differenced.
    if bench is not None:
        b = bench.reindex(seg.index).ffill()
        for h in HORIZONS:
            if len(seg) > h and b.notna().iloc[0] and b.notna().iloc[h]:
                r = np.log(close.iloc[h] / close.iloc[0]) * 100.0 * sign
                m = np.log(b.iloc[h] / b.iloc[0]) * 100.0 * sign
                out[f"exc_{h}w"] = round(float(r - m), 2)

    if out["stopped"]:
        out["outcome"] = "stopped out"
    elif out["hit_t1"]:
        out["outcome"] = "reached first target"
    elif out["triggered"]:
        out["outcome"] = "open"
    elif out["weeks_tracked"] >= TRACK_WEEKS:
        out["outcome"] = "never triggered"
    else:
        out["outcome"] = "watching"
    return out


def update(scan: pd.DataFrame, feats: dict, benches: dict, meta: dict,
           asof, regime: str, path: str = SIGNALS) -> pd.DataFrame:
    """Append this week's signals and re-track everything still open."""
    asof = str(pd.Timestamp(asof).date())
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    old = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame(columns=FROZEN + OUTCOME)

    fresh = [r for r in (_row_from(rec, asof, regime)
                         for rec in scan.to_dict("records")) if r]
    known = set(old["signal_id"]) if len(old) else set()
    added = [r for r in fresh if r["signal_id"] not in known]

    log = pd.concat([old, pd.DataFrame(added)], ignore_index=True) if added else old.copy()
    for c in FROZEN + OUTCOME:
        if c not in log.columns:
            log[c] = None
    if log.empty:
        log.to_csv(path, index=False)
        return log

    # Re-track anything not yet closed. Closed rows are never touched again, so
    # the record of what happened cannot be rewritten by a later run.
    live = log["outcome"].isna() | log["outcome"].isin(["watching", "open"])
    for i in log.index[live]:
        t = log.at[i, "ticker"]
        if t not in feats:
            continue
        m = meta.get(t, {})
        bench = benches.get(m.get("market"))
        try:
            for k, v in _track(log.loc[i], feats[t], bench).items():
                log.at[i, k] = v
        except Exception:                             # noqa: BLE001
            continue

    log = log[FROZEN + OUTCOME]
    log.to_csv(path, index=False)
    print(f"  journal: {len(added)} new signal(s), {int(live.sum())} tracked, "
          f"{len(log)} total in {path}")
    return log


def summarise(path: str = SIGNALS) -> pd.DataFrame:
    """
    What the forward log says so far, with its own sample size stated.

    Deliberately plain. There is no confidence interval here because with a
    handful of episodes any interval would span every outcome worth
    distinguishing, and printing one would imply more than the data supports.
    """
    if not os.path.exists(path):
        return pd.DataFrame()
    log = pd.read_csv(path)
    if log.empty:
        return pd.DataFrame()
    rows = []
    for (kind, grade), g in log.groupby(["kind", "grade"], dropna=False):
        done = g[g["outcome"].isin(["stopped out", "reached first target",
                                    "never triggered"])]
        exc = pd.to_numeric(g.get("exc_13w"), errors="coerce").dropna()
        rows.append({
            "kind": kind, "grade": grade, "signals": len(g),
            "weeks_of_history": int(pd.to_numeric(g["weeks_tracked"],
                                                  errors="coerce").max() or 0),
            "triggered_pct": round(float(pd.to_numeric(g["triggered"], errors="coerce")
                                         .fillna(0).mean()) * 100, 1),
            "stopped_pct": round(float(pd.to_numeric(g["stopped"], errors="coerce")
                                       .fillna(0).mean()) * 100, 1),
            "hit_t1_pct": round(float(pd.to_numeric(g["hit_t1"], errors="coerce")
                                      .fillna(0).mean()) * 100, 1),
            "median_exc_13w": round(float(exc.median()), 2) if len(exc) else None,
            "n_with_13w": len(exc),
            "resolved": len(done),
        })
    return pd.DataFrame(rows).sort_values(["kind", "grade"])
