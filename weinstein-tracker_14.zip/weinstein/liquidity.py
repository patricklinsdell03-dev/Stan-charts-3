"""
Can you actually buy it?

A Weinstein breakout on a line that trades fifty thousand pounds a day is not a
trade, it is a screenshot. The chart pattern is real, the entry is real, and the
spread takes a chunk of the move before you have finished buying. Widening a
universe into small caps without a liquidity screen does not add opportunities,
it adds rows that look identical to the good ones and behave nothing like them.

Three measures, because they fail differently
---------------------------------------------
1. Average daily value traded, converted to sterling. The headline number, and
   the one that decides whether a given position size is a rounding error in the
   day's flow or a visible part of it.

2. Dead weeks. The count of recent weeks with no volume at all. A line can post
   a respectable average because of two block trades and be untradeable on any
   given day. The average alone cannot see this.

3. Amihud illiquidity: the average of absolute weekly return divided by the
   value traded that week. This is the standard academic proxy for price impact
   and it answers the question the other two cannot, which is how far the price
   moves when someone does trade. A thin line with a high reading gaps around on
   small orders, and a breakout measured on those gaps is measuring noise.

On the currency conversion
--------------------------
UK lines quote in pence, US lines in dollars, and comparing the raw products
would rank a penny stock above a megacap. The sterling rate is pulled from the
same price source as everything else rather than hardcoded, because a constant
put in today is wrong within a month and silently distorts the floor for every
UK-versus-US comparison the screen makes.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# Sized for the position this account actually places. Under a thousand pounds
# against a hundred thousand a day is about one per cent of daily flow, which is
# invisible to the market. Raise it as position size grows: the right floor is
# roughly a hundred times the intended position.
MIN_ADV_GBP = 100_000.0

# Below this the line is not thin, it is closed for business.
DEAD_ADV_GBP = 25_000.0

LOOKBACK_WEEKS = 26
DEAD_WEEK_LIMIT = 3          # zero-volume weeks tolerated in the lookback
TRADING_DAYS_PER_WEEK = 5.0

# Amihud above this reads as a line whose price jumps on ordinary order sizes.
# Scaled so the number is "percent price move per million pounds traded".
AMIHUD_WARN = 2.0

FX_TICKER = "GBPUSD=X"

STATUS_OK = "ok"
STATUS_THIN = "thin"
STATUS_UNTRADEABLE = "untradeable"
STATUS_UNKNOWN = "unknown"


def currency_of(ticker: str) -> str:
    """
    The quote currency of a listing, from its suffix. Yahoo quotes London lines
    in pence, not pounds, which is a factor of a hundred and therefore not a
    rounding detail.
    """
    t = str(ticker).upper()
    if t.endswith(".L"):
        return "GBp"
    if t.endswith("-USD") or t.endswith("-GBP"):
        return "USD" if t.endswith("-USD") else "GBP"
    return "USD"


def to_gbp_factor(ticker: str, usd_gbp: float) -> float:
    """Multiplier taking one unit of the listing's quote currency into pounds."""
    cur = currency_of(ticker)
    if cur == "GBp":
        return 0.01
    if cur == "GBP":
        return 1.0
    return float(usd_gbp)


def fx_usd_gbp(prices: dict[str, pd.DataFrame], default: float = 0.79) -> float:
    """
    Pounds per dollar, from the FX series if it was downloaded. Falls back to a
    stated default rather than failing, because a missing FX quote should not
    take down a scan, but the default is deliberately visible in the log so a
    stale number cannot masquerade as a live one.
    """
    df = prices.get(FX_TICKER)
    if df is None or df.empty or "close" not in df:
        return float(default)
    s = pd.to_numeric(df["close"], errors="coerce").dropna()
    if s.empty:
        return float(default)
    rate = float(s.iloc[-1])          # GBPUSD is dollars per pound
    if not np.isfinite(rate) or rate <= 0:
        return float(default)
    return 1.0 / rate


def measure(df: pd.DataFrame, ticker: str, usd_gbp: float,
            lookback: int = LOOKBACK_WEEKS) -> dict:
    """
    Liquidity of one line. Returns sterling average daily value, dead weeks,
    the Amihud impact proxy, and a status. Never raises: a line with unusable
    volume data comes back "unknown", which is shown rather than treated as ok.
    """
    blank = {"adv_gbp": np.nan, "dead_weeks": np.nan, "amihud": np.nan,
             "liquidity_status": STATUS_UNKNOWN, "liquidity_note": ""}
    if df is None or df.empty or not {"close", "volume"} <= set(df.columns):
        return blank

    tail = df.tail(lookback)
    close = pd.to_numeric(tail["close"], errors="coerce")
    vol = pd.to_numeric(tail["volume"], errors="coerce")
    if close.dropna().empty or vol.dropna().empty:
        return blank

    f = to_gbp_factor(ticker, usd_gbp)
    weekly_value = (close * vol * f).replace([np.inf, -np.inf], np.nan)
    usable = weekly_value.dropna()
    if usable.empty:
        return blank

    # Median, not mean. One index-rebalance week can be fifty times a normal
    # week's volume, and a mean built on that reports a liquidity that exists on
    # exactly one day of the year.
    adv = float(usable.median()) / TRADING_DAYS_PER_WEEK
    dead = int((vol.fillna(0) <= 0).sum())

    ret = close.pct_change().abs()
    # Percent move per million pounds of value traded.
    impact = (ret * 100.0) / (weekly_value / 1e6)
    impact = impact.replace([np.inf, -np.inf], np.nan).dropna()
    amihud = float(impact.median()) if len(impact) else np.nan

    notes = []
    if adv < DEAD_ADV_GBP:
        status = STATUS_UNTRADEABLE
        notes.append(f"about £{adv:,.0f} a day changes hands, which is not a "
                     "market you can get in and out of")
    elif adv < MIN_ADV_GBP or dead > DEAD_WEEK_LIMIT:
        status = STATUS_THIN
        if adv < MIN_ADV_GBP:
            notes.append(f"only about £{adv:,.0f} a day changes hands")
        if dead > DEAD_WEEK_LIMIT:
            notes.append(f"{dead} of the last {len(tail)} weeks had no trading at all")
    else:
        status = STATUS_OK

    if np.isfinite(amihud) and amihud > AMIHUD_WARN and status == STATUS_OK:
        status = STATUS_THIN
        notes.append("the price moves a long way on ordinary order sizes, so the "
                     "levels on the chart are softer than they look")

    return {"adv_gbp": adv, "dead_weeks": dead, "amihud": amihud,
            "liquidity_status": status, "liquidity_note": "; ".join(notes)}


#: Liquidity caps the grade rather than removing the row, so a thin line stays
#: visible and explains itself instead of disappearing without a reason.
CAP = {STATUS_THIN: "C", STATUS_UNTRADEABLE: "D"}

_ORDER = {"A": 0, "B": 1, "C": 2, "D": 3}


def apply(rec: dict, info: dict) -> dict:
    """Folds a liquidity measurement into a scored record. Only ever lowers."""
    rec = dict(rec)
    rec.update({k: info.get(k) for k in
                ("adv_gbp", "dead_weeks", "amihud", "liquidity_status")})

    sig = rec.get("signal")
    if not isinstance(sig, dict):
        return rec

    sig = dict(sig)
    sig["liquidity_status"] = info.get("liquidity_status")
    sig["adv_gbp"] = info.get("adv_gbp")

    cap = CAP.get(info.get("liquidity_status"))
    if cap:
        cur = sig.get("grade")
        if cur in _ORDER and _ORDER[cap] > _ORDER[cur]:
            sig["grade"] = cap
        note = info.get("liquidity_note") or "this line is thinly traded"
        sig["notes"] = ((sig.get("notes") or "") + ("; " if sig.get("notes") else "")
                        + note + f". Graded no better than {cap} for that.")

    rec["signal"] = sig
    rec["grade"] = sig.get("grade")
    return rec
