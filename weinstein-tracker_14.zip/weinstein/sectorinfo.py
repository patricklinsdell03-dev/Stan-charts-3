"""
Sector labels for the names no index list covers.

The Trading 212 instruments endpoint returns ticker, ISIN, name, type and
currency, and no sector. So every name the broker adds arrives with an empty
sector, which means it joins no composite, contributes to no group, and is
scored with a neutral group factor that reads as "no opinion" rather than as
"fine". Since the broker list is about to be most of the universe, that would
quietly switch off Weinstein's group precondition for the majority of the scan
while the dashboard carried on looking complete.

Yahoo knows the sector for almost all of them. The cost is one request per
ticker, which is why this is a budgeted backfill against a permanent cache
rather than something the scan does every week for every name:

  - Sectors effectively never change, so a hit is cached forever. Unlike the
    events cache, which expires after five days, this one has no TTL.
  - Only names with no sector are looked up at all.
  - Each run spends a fixed budget of requests and stops. A first run over
    several thousand new names fills in part of the list; the following weeks
    fill in the rest. That is deliberate: a partial sector map is worth having
    immediately, and a scan that runs for six hours because of a one-off
    backfill is a scan that will hit a timeout on the week it matters.
  - A failure is cached as a failure, so a delisted or unmapped ticker is not
    retried forever, but is retried eventually.

Everything this returns goes through taxonomy.canonical before it reaches a
composite key, because Yahoo's scheme and Wikipedia's are not the same scheme.
"""

from __future__ import annotations

import os
import time

import pandas as pd

CACHE_DIR = os.environ.get("WEINSTEIN_CACHE", "cache")
CACHE = os.path.join(CACHE_DIR, "sectors.csv")

#: Requests per run. At roughly a third of a second each this is about ten
#: minutes, which is affordable beside a download that already takes hours.
DEFAULT_BUDGET = 2000

#: A ticker whose lookup failed is retried after this many runs, not never and
#: not every week.
RETRY_AFTER_RUNS = 8

FAILED = "__FAILED__"


def _load(path: str) -> tuple[dict[str, str], dict[str, int]]:
    sectors: dict[str, str] = {}
    misses: dict[str, int] = {}
    if not os.path.exists(path):
        return sectors, misses
    try:
        df = pd.read_csv(path)
    except Exception:                                    # noqa: BLE001
        return sectors, misses
    for _, r in df.iterrows():
        t = str(r.get("ticker") or "").strip()
        if not t:
            continue
        s = str(r.get("sector") or "").strip()
        sectors[t] = s
        try:
            misses[t] = int(r.get("misses") or 0)
        except (TypeError, ValueError):
            misses[t] = 0
    return sectors, misses


def _save(sectors: dict[str, str], misses: dict[str, int], path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    pd.DataFrame([{"ticker": t, "sector": s, "misses": misses.get(t, 0)}
                  for t, s in sorted(sectors.items())]).to_csv(path, index=False)


def _lookup(yf, ticker: str) -> str | None:
    """Yahoo's sector for one ticker, or None if the lookup gave nothing."""
    try:
        info = yf.Ticker(ticker).get_info()
    except Exception:                                    # noqa: BLE001
        return None
    if not isinstance(info, dict):
        return None
    for key in ("sector", "sectorDisp", "industryDisp", "industry"):
        v = info.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


def backfill(uni: pd.DataFrame, budget: int = DEFAULT_BUDGET,
             pause: float = 0.3, cache_path: str | None = None,
             verbose: bool = True) -> pd.DataFrame:
    """
    Fills empty sectors from the cache first, then spends its request budget on
    whatever is still missing. Returns a copy of the universe; never raises.
    """
    if uni is None or uni.empty or "sector" not in uni.columns:
        return uni
    path = cache_path or CACHE
    uni = uni.copy()
    uni["sector"] = uni["sector"].astype(str).replace(
        {"nan": "", "None": "", "-": ""}).str.strip()

    sectors, misses = _load(path)

    # 1. Free: anything already known.
    known = {t: s for t, s in sectors.items() if s and s != FAILED}
    filled = 0
    blank = uni["sector"].eq("")
    for i in uni.index[blank]:
        t = uni.at[i, "ticker"]
        if t in known:
            uni.at[i, "sector"] = known[t]
            filled += 1
    if verbose and filled:
        print(f"  sector cache filled {filled} name(s) with no lookup")

    # 2. Paid: what is still missing, cheapest first.
    still = [uni.at[i, "ticker"] for i in uni.index[uni["sector"].eq("")]]
    due = [t for t in still
           if sectors.get(t) != FAILED or misses.get(t, 0) >= RETRY_AFTER_RUNS]
    if not due:
        if verbose and still:
            print(f"  {len(still)} name(s) still without a sector, all of them "
                  "recent failed lookups awaiting retry")
        return uni

    try:
        import yfinance as yf
    except ImportError:
        if verbose:
            print("  yfinance unavailable, sector backfill skipped")
        return uni

    take = due[:max(0, int(budget))]
    if verbose:
        print(f"  looking up sectors for {len(take)} of {len(due)} name(s)"
              f" still missing one (budget {budget} per run)")

    got = 0
    for n, t in enumerate(take, 1):
        s = _lookup(yf, t)
        if s:
            sectors[t] = s
            misses[t] = 0
            got += 1
        else:
            sectors[t] = FAILED
            misses[t] = misses.get(t, 0) + 1
        if verbose and n % 250 == 0:
            print(f"    {n} of {len(take)}")
        time.sleep(pause)

    _save(sectors, misses, path)
    if verbose:
        print(f"  sector backfill: {got} resolved, {len(take) - got} unavailable,"
              f" {max(0, len(due) - len(take))} left for next run")

    lookup = {t: s for t, s in sectors.items() if s and s != FAILED}
    for i in uni.index[uni["sector"].eq("")]:
        t = uni.at[i, "ticker"]
        if t in lookup:
            uni.at[i, "sector"] = lookup[t]
    return uni
