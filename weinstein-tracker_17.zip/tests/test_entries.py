"""
Verification of the second-entry work: the equal-weighted benchmark, the widened
signal window, the pullback list and plan, the persistent watchlist, and the
index rebalance filter.

Same standard as the rest: every check runs the real function, and the ones
guarding a specific defect are written so that removing the fix makes them fail.
The defect this file mostly exists for is structural rather than arithmetic --
a textbook Weinstein pullback buy appeared on no list at all, because it was too
old for the breakout window and excluded from the watchlist for being in Stage 2.
Nothing errored. The entry simply could not be seen.
"""
import sys, os, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from weinstein import (market as M, plan as PL, rebalance as RB, scan as SC,
                       stages as S, watchlist as WL, features as F, synth)


def _frame(n=160, drift=0.004, vol=0.03, seed=1, start="2023-01-02"):
    rng = np.random.default_rng(seed)
    ix = pd.date_range(start, periods=n, freq="W-MON")
    c = 100.0 * np.cumprod(1.0 + rng.normal(drift, vol, n))
    return pd.DataFrame({"open": c, "high": c * 1.02, "low": c * 0.98,
                         "close": c, "volume": 1e6}, index=ix)


def main():
    bad = []

    # =====================================================================
    # 1. THE EQUAL-WEIGHTED BENCHMARK
    # =====================================================================
    px, meta = {}, {}
    for i in range(45):
        # One name runs away from the rest, the way a mega-cap does. A
        # cap-weighted index would follow it; an equal-weighted one should not.
        drift = 0.02 if i == 0 else 0.002
        px[f"T{i}"] = _frame(drift=drift, seed=i)
        meta[f"T{i}"] = {"market": "US"}

    ew = M.equal_weight_composite(px, meta, "US")
    cap = px["T0"]["close"]            # stand-in for a concentrated index
    print(f"equal-weighted composite: {len(ew)} weeks, "
          f"total return {float(ew.iloc[-1]/ew.iloc[0]-1)*100:.0f}% vs "
          f"{float(cap.iloc[-1]/cap.iloc[0]-1)*100:.0f}% for the runaway name")
    if ew.empty:
        bad.append("no equal-weighted composite was built from 45 names")
    else:
        # The whole point: an ordinary stock measured against the concentrated
        # index looks weak, and against the average stock does not.
        ordinary = px["T7"]["close"]
        rs_ew = F.mansfield_rs(ordinary, ew, min_coverage=0.0).dropna()
        rs_cap = F.mansfield_rs(ordinary, cap, min_coverage=0.0).dropna()
        if rs_ew.empty or rs_cap.empty:
            bad.append("relative strength could not be computed for the comparison")
        else:
            d = float(rs_ew.iloc[-1] - rs_cap.iloc[-1])
            print(f"ordinary name: RS {rs_ew.iloc[-1]:+.1f} vs the average stock, "
                  f"{rs_cap.iloc[-1]:+.1f} vs the runaway index (gap {d:+.1f})")
            if abs(d) < 1e-6:
                bad.append("the two benchmarks give the same reading, so switching "
                           "them cannot be doing anything")

    # Membership guards.
    if not M.equal_weight_composite(px, meta, "US", min_names=100).empty:
        bad.append("a composite was built from fewer names than its own minimum")
    if not M.equal_weight_composite(px, meta, "UK").empty:
        bad.append("a market with no constituents still produced a composite")
    sub = M.equal_weight_composite(px, meta, "US", eligible=set(list(px)[:35]),
                                   min_names=30)
    if sub.empty:
        bad.append("an eligible subset above the minimum produced nothing")
    elif len(sub) == len(ew) and float((sub - ew).abs().max()) < 1e-12:
        bad.append("restricting membership had no effect on the composite")

    # =====================================================================
    # 2. THE SIGNAL WINDOW
    # =====================================================================
    print(f"signal window: {S.SIGNAL_WINDOW - 1} weeks of lookback")
    if S.SIGNAL_WINDOW - 1 < 8:
        bad.append(f"the signal window is {S.SIGNAL_WINDOW - 1} weeks, which closes "
                   "before most pullback entries arrive")
    # It must not read past the start of a short frame.
    short = F.compute_features(_frame(n=F.MIN_HISTORY + 2), _frame(n=F.MIN_HISTORY + 2)["close"])
    try:
        S.evaluate(short.assign(group_factor=1.0, group_factor_dn=1.0,
                                sector_rs=np.nan, rs_vs_sector=np.nan),
                   "SHORTHIST", "Short History", "US", "", market_ok=True)
        print("short history: evaluate survived a frame barely longer than the window")
    except Exception as e:                           # noqa: BLE001
        bad.append(f"a frame shorter than the signal window broke evaluate: {e!r}")

    # =====================================================================
    # 3. THE PULLBACK PLAN
    # =====================================================================
    row = {"close": 102.0, "ma30": 100.0, "atr": 3.0, "ma_slope_pct": 1.4,
           "recent_high_10w": 118.0, "recent_low_10w": 99.0}
    pb = PL.build_pullback_plan(row)
    print(f"pullback plan: entry {pb['pullback_high']}, stop {pb['stop']}, "
          f"risk {pb['risk_pct']}%, t1 {pb['t1']} ({pb['t1_r']}R)")
    if pb is None:
        bad.append("no pullback plan was produced for a textbook pullback")
    else:
        if not (pb["stop"] < row["ma30"]):
            bad.append("the pullback stop is not below the 30 week average, so "
                       "ordinary noise around the line takes the trade out")
        if not (pb["stop"] < pb["pullback_high"]):
            bad.append("the pullback stop is not below its own entry")
        if not (pb["t1"] > pb["pullback_high"]):
            bad.append("the pullback target is not above its entry")
        if pb.get("trigger") is not None:
            bad.append("a pullback plan carries a breakout trigger, which is a "
                       "different trade")
        if pb["risk_pct"] > PL.DEFAULT.max_stop_pct + 1e-9:
            bad.append("the pullback stop exceeds the configured maximum risk")

    # A falling average is not a pullback, it is a downtrend.
    if PL.build_pullback_plan({**row, "ma_slope_pct": -0.5}) is not None:
        bad.append("a pullback plan was produced while the 30 week average was falling")
    # Nor is a stop inside the weekly noise a stop.
    tiny = PL.build_pullback_plan({**row, "atr": 0.01, "recent_low_10w": 99.99})
    if tiny is not None and tiny["risk_pct"] < PL.DEFAULT.min_risk_pct:
        bad.append("a pullback plan was produced with a stop inside the noise")

    # Alerts must survive a plan with no trigger.
    try:
        rows = PL.alert_rows({"ticker": "X", "plan": pb})
        kinds = [r["type"] for r in rows]
        print(f"pullback alerts: {kinds}")
        if "BUY STOP" in kinds:
            bad.append("a pullback plan emitted a breakout stop order")
        if "BUY LIMIT" not in kinds:
            bad.append("a pullback plan emitted no buy limit, which is its entry")
    except Exception as e:                           # noqa: BLE001
        bad.append(f"alert_rows broke on a plan with no trigger: {e!r}")

    # =====================================================================
    # 4. THE PULLBACK LIST -- the structural gap
    # =====================================================================
    # A Stage 2 name back at a rising 30 week line with positive relative
    # strength, and no fresh break. Before the pullbacks list this row was on
    # no list at all: too old for breakouts, excluded from watch_stage2 for
    # being in Stage 2.
    base = {"ticker": "PB", "name": "Pullback Co", "market": "US", "index": "X",
            "sector": "Industrials", "stage": "Stage 2", "trend_score": 55.0,
            "stage2_readiness": 60.0, "stage4_readiness": 10.0,
            "px_vs_ma_pct": 1.5, "ma_slope_pct": 1.2, "mansfield_rs": 4.0,
            "dist_to_resistance_pct": 9.0, "signal": None, "grade": None,
            "close": 100.0}
    rows = [base,
            {**base, "ticker": "EXT", "px_vs_ma_pct": 22.0},      # extended
            {**base, "ticker": "FALL", "ma_slope_pct": -0.4},     # rolling over
            {**base, "ticker": "LAG", "mansfield_rs": -2.0},      # lagging
            {**base, "ticker": "BRK",
             "signal": {"kind": "stage2_breakout", "confirmed": True}}]
    lists = SC.slice_lists(pd.DataFrame(rows), top=40)
    got = list(lists["pullbacks"]["ticker"])
    print(f"pullback list kept: {got}")
    if "PB" not in got:
        bad.append("the textbook pullback did not reach the pullback list, which "
                   "is the entire reason the list exists")
    for t, why in (("EXT", "extended well above the line"),
                   ("FALL", "the 30 week average is falling"),
                   ("LAG", "relative strength is negative"),
                   ("BRK", "it is this week's fresh breakout, not a pullback")):
        if t in got:
            bad.append(f"{t} reached the pullback list despite {why}")
    # And confirm the old behaviour really did lose it.
    if "PB" in list(lists["watch_stage2"]["ticker"]):
        bad.append("a Stage 2 name is in the Approaching Stage 2 list, so the "
                   "fixture does not reproduce the gap this list fills")

    # =====================================================================
    # 5. THE PERSISTENT WATCHLIST
    # =====================================================================
    feat = F.compute_features(_frame(seed=3), _frame(seed=4)["close"])
    good = feat.copy()
    good.loc[good.index[-1], ["close", "ma30", "ma_slope_pct", "mansfield_rs"]] = \
        [100.0, 95.0, 1.2, 3.0]
    broken = feat.copy()
    broken.loc[broken.index[-1], ["close", "ma30", "ma_slope_pct", "mansfield_rs"]] = \
        [90.0, 95.0, 1.2, 3.0]              # closed below the 30 week average

    asof = pd.Timestamp(feat.index[-1]).date()
    recent = (asof - dt.timedelta(weeks=2)).isoformat()
    old_date = (asof - dt.timedelta(weeks=WL.MAX_AGE_WEEKS + 4)).isoformat()

    cases = [
        ({"ticker": "A", "added_on": recent, "side": "long",
          "entry_type": "BUY LIMIT", "entry_price": 1e9}, {"A": good},
         WL.STATUS_TRIGGERED, "an entry far above price must read as filled"),
        ({"ticker": "B", "added_on": recent, "side": "long",
          "entry_type": "BUY LIMIT", "entry_price": 1e-6}, {"B": broken},
         WL.STATUS_INVALID, "a close below the 30 week average must cancel the order"),
        ({"ticker": "C", "added_on": old_date, "side": "long",
          "entry_type": "BUY LIMIT", "entry_price": 1e-6}, {"C": good},
         WL.STATUS_EXPIRED, "an order older than the maximum age must expire"),
        ({"ticker": "D", "added_on": recent, "side": "long",
          "entry_type": "BUY LIMIT", "entry_price": 1e-6}, {"D": good},
         WL.STATUS_WAITING, "an intact setup that has not filled must still be waiting"),
        ({"ticker": "E", "added_on": recent, "side": "long",
          "entry_type": "BUY LIMIT", "entry_price": 1e-6}, {},
         WL.STATUS_UNKNOWN, "a ticker outside the scan must report unknown, not ok"),
    ]
    for row_in, feats, want, why in cases:
        got_s = WL.review([row_in], feats, asof=asof)[0]
        if got_s["status"] != want:
            bad.append(f"watchlist: {why} (got {got_s['status']})")
        if not got_s["reason"]:
            bad.append(f"watchlist: {row_in['ticker']} carries no reason for its status")
    print("watchlist statuses: " +
          ", ".join(f"{c[0]['ticker']}={WL.review([c[0]], c[1], asof=asof)[0]['status']}"
                    for c in cases))

    # A malformed or missing file must never raise.
    if WL.load("/nonexistent/path/watchlist.csv") != []:
        bad.append("a missing watchlist file did not load as empty")

    # =====================================================================
    # 6. INDEX REBALANCE DATES
    # =====================================================================
    d2026 = dict((n, d) for d, n in RB.dates_for(2026))
    print("2026 rebalance dates: " +
          ", ".join(f"{v}" for _, v in sorted(d2026.items())))
    for name, d in d2026.items():
        if d.weekday() != 4:
            bad.append(f"{name} on {d} is not a Friday")
    if len(RB.dates_for(2026)) < 5:
        bad.append("fewer than five rebalance dates in a year")

    near = RB.classify(dt.date(2026, 6, 26))
    clear = RB.classify(dt.date(2026, 8, 21))
    if near["rebalance_status"] != RB.STATUS_NEAR:
        bad.append("Russell reconstitution week was not flagged")
    if clear["rebalance_status"] != RB.STATUS_CLEAR:
        bad.append("an ordinary August week was flagged as a rebalance")
    if RB.classify(None)["rebalance_status"] != RB.STATUS_CLEAR:
        bad.append("a missing signal date was flagged rather than left clear")

    # Only ever lowers.
    order = {"A": 0, "B": 1, "C": 2, "D": 3}
    raised = []
    for g in order:
        for info in (near, clear):
            out = RB.apply({"ticker": "T", "grade": g,
                            "signal": {"kind": "stage2_breakout", "grade": g,
                                       "notes": ""}}, info)
            if order[out["signal"]["grade"]] < order[g]:
                raised.append((g, info["rebalance_status"], out["signal"]["grade"]))
    if raised:
        bad.append(f"the rebalance flag raised a grade: {raised[:3]}")
    capped = RB.apply({"ticker": "T", "grade": "A",
                       "signal": {"kind": "stage2_breakout", "grade": "A",
                                  "notes": ""}}, near)
    print(f"rebalance cap: an A in reconstitution week becomes {capped['grade']}")
    if capped["grade"] != RB.CAP:
        bad.append(f"a rebalance-week A was not capped to {RB.CAP}")

    print("\n" + ("FAILURES:\n  " + "\n  ".join(bad) if bad
                  else "ENTRY AND BENCHMARK CHECKS PASSED"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
