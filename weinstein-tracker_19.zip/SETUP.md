# Setup, and the one thing that goes wrong

## The failure you are most likely to hit

**Symptom:** the Actions tab never asks you to enable workflows, and after
setting up Pages there is no workflow to run.

**Cause:** the `.github` folder did not upload. GitHub's web uploader, and most
operating systems' unzip and drag-and-drop, silently skip folders whose name
begins with a dot. There is no error. The folder simply is not there.

**Confirm it in one step.** Open this URL, substituting your details:

    https://github.com/YOUR-NAME/YOUR-REPO/blob/main/.github/workflows/weekly-scan.yml

A 404 means the folder is missing, which is the whole problem. If the file loads,
the cause is something else and the checklist further down applies.

**Fix it from a browser, phone included.** Do not fight the uploader.

1. In the repository, choose **Add file**, then **Create new file**.
2. In the filename box type `.github/workflows/weekly-scan.yml` in full. Typing
   each `/` turns the preceding text into a folder as you go, which is how you
   create a dot-folder in the web interface.
3. Paste the contents of `WORKFLOW-COPY-ME.yml` from this project, minus its
   comment header, and commit.
4. Reload the Actions tab. The workflow appears, with a **Run workflow** button
   on the right.

That header note is why `WORKFLOW-COPY-ME.yml` sits in the root of this project
rather than only in `.github/`. Delete it once the real one is in place.

## If the file is there and it still does not run

Work down this list in order.

**Default branch.** Settings, then Branches. `workflow_dispatch` only offers a
Run workflow button for workflows on the default branch. If yours is `master`
rather than `main`, either rename it or change the Pages source to match.

**Actions permissions.** Settings, then Actions, then General. "Allow all
actions and reusable workflows" must be selected. A brand new account sometimes
also needs its email verified before any workflow will start.

**Write permission.** The workflow commits the regenerated dashboard back to the
repository. Settings, then Actions, then General, then Workflow permissions:
"Read and write permissions" must be selected, otherwise the run does all the
work and fails on the final push.

**Look at the run, not the tab.** If a run started and failed, the Actions tab
shows a red cross rather than nothing at all. Open it and read the failing step.
The scan itself takes fifteen to thirty minutes on the first run because it is
downloading 1,250 price histories.

## The rest of the setup

1. Free account at github.com.
2. New repository, public. GitHub Pages only serves public repositories on the
   free tier. If you would rather keep it private, skip the Pages step and take
   the dashboard from each run's artifacts instead.
3. Upload everything from inside the `weinstein-tracker` folder, keeping the
   folder structure. Assume `.github` did not make it and use the Create new
   file method above for the workflow.
4. Settings, then Pages. Source: Deploy from a branch. Branch `main`, folder
   `/docs`. Save.
5. Actions, then Weekly Weinstein scan, then Run workflow.
6. When it finishes the dashboard is at `yourname.github.io/yourrepo`.

Before the first real order, run `./run_tests.sh` once from a laptop. Five
suites, a few seconds, no network needed. It is the only evidence you have that
the arithmetic does what it claims.

---

## The expansion: events, liquidity, Trading 212 and crypto

Four things changed. Only one of them needs anything from you.

### 1. The earnings filter (automatic, nothing to do)

Every signal now gets its results diary checked. Two separate questions:

- **Did the breakout fire on the back of an event?** If a results date or
  trading statement falls within 12 days before the end of the signal week,
  the row is marked `event_driven` and capped at grade **C**. Twelve days
  covers the signal week and the one before it, because a Wednesday gap often
  does not confirm a breakout until the following Friday close — which is
  exactly what happened on GFRD.L, where the 15 July trading statement
  produced a signal stamped 20 July.
- **Are results due while you would be holding?** Anything inside 28 days is
  marked `event_ahead` and capped at grade **B**.

A line whose diary cannot be found reads `unknown`, not `clear`. It is shown
and not penalised: a thin data source is not the same as a bad chart, and
docking UK small caps for Yahoo's patchy coverage would be punishing the wrong
thing.

**This is a flag, not a verdict.** Three pre-trade audits is an anecdote, not a
base rate. The flag is frozen into `log/signals.csv` at first sighting, so in a
few months you can ask your own forward record whether event-driven breakouts
actually do worse, instead of taking my word for it.

Only tickers that already carry a signal get looked up — roughly 200 requests
a week rather than five thousand — and the results are cached in
`cache/events.csv` for five days.

### 2. The liquidity screen (automatic, nothing to do)

Sized for positions under £1,000. Three measures, because they fail in
different ways:

- **Average daily value traded**, in sterling. Below £100,000 a day the row is
  marked `thin` and capped at **C**; below £25,000 it is `untradeable` and
  capped at **D**. Median rather than mean, so one index-rebalance week cannot
  manufacture a liquidity that exists on a single day of the year.
- **Dead weeks.** Weeks with no trading at all. A line can post a respectable
  average off two block trades and be unbuyable on any given Tuesday.
- **Amihud impact.** How far the price moves per million pounds traded. A
  high reading means the levels on the chart are softer than they look.

If you raise your position size, raise `MIN_ADV_GBP` in
`weinstein/liquidity.py` with it. The rule of thumb is roughly **100× your
intended position**.

The sterling rate is downloaded with the prices (`GBPUSD=X`) rather than
hardcoded. London lines quote in **pence**, and that factor of a hundred is
handled explicitly — getting it wrong would make every UK name look a hundred
times more liquid than it is.

### 3. Trading 212 tradeability (needs one secret from you)

Optional. Without it, nothing breaks — the scan runs on index membership as
before.

1. In the Trading 212 app: **Settings → API (Beta) → Generate key**. Read-only
   is enough.
2. In your repo: **Settings → Secrets and variables → Actions → New repository
   secret**. Name it exactly `T212_API_KEY`, paste the key, save.

With the secret present, every scheduled run adds the tradeable names no index
list covers. Tick **tradeable_only** on a manual run to also drop index names
your account cannot buy.

Two honest limitations. Trading 212's instrument list carries **no sector**, so
names added this way score with a neutral group factor rather than a real one —
index names keep their sector and always win a collision. And T212 identifies
instruments in its own scheme (`MCRB_US_EQ` for US, `BPl_EQ` for London) with
no exchange field, so the market is inferred from ticker shape, ISIN country
and currency together, and an instrument where those three disagree is skipped
rather than guessed at. Share classes (`BT.A`, `BRK.B`) are where the mapping
genuinely cannot win — the separator is already gone from the broker's string.
Those either resolve wrongly and get dropped when no price series comes back,
or never resolve at all.

### 4. The crypto board (automatic, its own page)

Published to `docs/crypto.html`, linked from the top of the stock dashboard.
Same verdicts and grades, but four things are calibrated differently:

- **Weeks end Sunday**, not Friday. Crypto trades every day, and using the
  equity rule would treat a bar with two days left to run as finished — the
  same class of bug as the Friday fix, in the other direction.
- **The benchmark is an equal-weighted crypto composite**, not bitcoin.
  Measured against bitcoin, bitcoin has a relative strength of zero by
  construction and falls out of its own scan.
- **Its own regime gauge**, from that composite and the breadth of the board.
  Crypto is not in a bull market because the S&P is.
- **A measured volatility scalar.** Every percentage threshold in the scoring
  layer was chosen against equity volatility: 12% above the 30-week line is a
  stretched equity and an ordinary week for a coin. Rather than fork the
  scoring code — which would double the surface the row-versus-vectorised
  equivalence test has to cover — the percentage inputs are divided by one
  scalar before scoring, so the untouched equity code runs on
  equity-equivalent units. The scalar is the board's median weekly ATR over a
  stated equity reference, measured each run, bounded to 1×–6×. It is printed
  in the page subtitle.

Displayed numbers are always the real ones. Stops and targets are built on the
real frame, with a 30% maximum stop instead of 12%, because a 12% stop sits
inside one ordinary week for most coins.

There is deliberately **no sector layer** for crypto. Sector taxonomies exist
but no free source gives point-in-time membership, and a group factor built on
a current one would look exactly like the equity board's and mean nothing. It
sits at a neutral 1.0. There are no earnings either, so the event filter
reports `not_applicable` rather than handing every coin a pass the stocks have
to earn.

Edit `COINS` in `weinstein/crypto.py` to match what Trading 212 actually offers
you.

### 5. Sector labels for the broker names

Trading 212's instrument list carries **no sector**. On its own, that meant
every name the broker added joined no composite, contributed to no group, and
was scored with a neutral group factor — switching off Weinstein's group
precondition for what would soon be most of the universe, with the dashboard
still looking complete. Two things fix it.

**A budgeted sector backfill.** Yahoo knows the sector for nearly all of them.
Names with no sector are looked up one at a time and cached **permanently**
(sectors do not change, so unlike the events cache there is no expiry). Each
run spends a fixed budget — 2,000 lookups, about ten minutes — and stops, so a
first pass over several thousand new names fills in part of the list and the
following weeks fill in the rest. A partial sector map is worth having
immediately; a six-hour one-off backfill is a timeout on the week it matters.
Override with `--sector-budget N`, or `0` to disable.

**One taxonomy.** This is the part that mattered more than expected. Sector
labels now arrive from three schemes that disagree on both names and
granularity:

| Source | Scheme | Example |
|---|---|---|
| Wikipedia, US | GICS, 11 sectors | `Information Technology` |
| Wikipedia, UK | ICB supersectors, 20 | `Software and Computer Services` |
| Yahoo | its own, 11 | `Technology` |

Composites are keyed on the sector string, so left unreconciled those three
form **three separate composites for one real group**. Each is thinner than the
group actually is, each falls below the five-member minimum more often, and a
stock ends up measured against a third of its peers — or, when every piece
falls under the minimum, against nothing at all, which is the silent version
and the reason every UK line on your dashboard showed a dash in its sector
columns.

Everything is now mapped onto the eleven GICS sectors before anything is keyed
on it. The test for this builds 18 tech names split across the three source
labels: **3 composites before normalising, 1 after.**

The trade is real and worth stating. Collapsing Banks and Insurance into
Financials loses granularity Weinstein would have used — he thinks in narrower
groups than these. It is taken anyway because a granular group with four
members is not a group, it is four stocks, and no composite gets built for it.
A slightly coarse group that exists beats an ideal group that does not.

A label the alias table does not recognise is **passed through unchanged and
reported in the run log** — never rebucketed into the nearest-looking group,
never silently dropped. It forms its own bucket, usually fails the member
minimum, and leaves a neutral group factor, which is the honest outcome for
"we do not know what this is". If you see unknown labels in the log, they are a
one-line addition to `_ALIASES` in `weinstein/taxonomy.py`.

---

## The second entry: pullbacks, pending orders and a fairer benchmark

### The gap this closes

A signal used to stay visible for four weeks. The Approaching Stage 2 list
excludes anything already in Stage 2. So the highest-quality entry Weinstein
has — an established Stage 2 stock that has come back to its still-rising 30
week average on quiet trade — appeared on **no list at all**. Too old for the
breakout list, excluded from the watchlist for being in Stage 2. Nothing
errored; the entry simply could not be seen.

Three changes fix it:

- **The signal window is now 12 weeks**, not four. A break stays visible for a
  quarter, which is the window its pullback actually arrives in.
- **A "Pullback buys" tab**: Stage 2 names within −3% to +8% of a rising 30
  week line, with relative strength still positive and no fresh break this
  week. Sorted by trend score.
- **A dedicated pullback plan.** It cannot reuse the breakout plan, which is
  built around a base pivot that is long gone. Entry is a limit just above the
  moving average; the stop sits below both the average and the recent swing
  low, by a multiple of weekly range; the first target is the prior high — a
  level the market has actually defended — rather than a projection. It is
  carried *alongside* the breakout plan, because a name can legitimately be
  both, and having only one loses the better of the two. Both sets of levels
  appear in the alerts CSV.

### watchlist.csv — the only part of the system with a memory

Copy `watchlist.example.csv` to `watchlist.csv` and add one row per order you
have actually placed:

```
ticker,added_on,side,entry_type,entry_price,stop,note
MSFT,2026-09-08,long,BUY LIMIT,412.50,384.00,pullback to the 30w line
```

Every scan then answers three questions about each row:

- **TRIGGERED** — price traded through your level, so it has almost certainly
  filled. Move it to `positions.csv` so the weekly management rules start
  applying.
- **CANCEL** — the entry level is unchanged but the setup that justified it is
  not: a close through the 30 week average, the average flattening, relative
  strength turning, or price already past your stop. *A resting order does not
  know any of that.* This is the failure it exists to prevent — a good limit
  from a month ago filling on a stock that has since rolled over, leaving you
  holding a Stage 4 name because the entry outlived its own reasoning.
- **EXPIRED** — 13 weeks without filling. The chart has moved on.

Nothing is ever placed or cancelled for you. It tells you which orders to pull.

### Relative strength now measures what Weinstein meant

The ten largest S&P names are roughly a third of the index. Measuring relative
strength against a cap-weighted index therefore asks whether a stock beats a
handful of mega-caps — not whether it beats *the average stock*, which is the
question Weinstein was asking. In a year when mega-cap tech runs, every other
name prints negative RS and his precondition rejects the whole market for a
reason that has nothing to do with the stocks being rejected.

RS is now measured against an **equal-weighted composite** built from the
universe already downloaded, restricted to names that clear the liquidity floor.
Sector composites use the same benchmark, so the group factor and the stock's
own reading are on one scale. The test makes the size of this concrete: an
ordinary name reads **−15.9 against the average stock and −40.8 against a
concentrated index**.

Two deliberate choices. The **regime headline stays on the cap-weighted index**,
because that is what "the market is up" means to everyone. And the old reading
is kept beside the new one as `mansfield_rs_cap`, display only, so you can see
whether a number moved because the stock moved or because the benchmark changed.

**This is a changeover.** RS figures from this run are not comparable with last
week's. If the composite cannot be built, the scan falls back to the index and
says so in the log.

### Index rebalance filter

Breaks landing within 7 days of a scheduled index review are flagged and capped
at grade B. The dates are arithmetic, not data: the third Friday of March, June,
September and December, plus the Russell annual reconstitution on the last
Friday of June.

The reasoning is the same as the earnings filter. Index funds buy on a known
date, in size, regardless of the chart — producing a decisive close on several
times normal volume that is forced flow, not accumulation. Passive is a far
larger share of the market than when the method was written, so this is a bigger
contaminant now than any amount of discretionary buying. As with events, this is
marked and frozen into the forward log rather than asserted: the claim that
rebalance-week breakouts do worse is measurable, and has not been measured here.

### Earlier profit taking

First target multiple capped at 2.0× base height (was 3.0), the projected move
capped at 45% (was 60%), 60% sold at the first target (was 50%), and the stop
moves to breakeven at 0.75R (was 1.0R). Information diffuses faster than it did
in 1988; a target that is rarely reached is not a plan, it is a reason to give
back an open gain.

### A silent bug this work uncovered

`positions.csv` shipped inside the zip, and the workflow extracts with
`unzip -o` on every run, because `weinstein/` is never committed and has to be
restored each week. **Your positions file was being overwritten with the blank
template before every single scan**, so open-position management had never once
run against real positions.

The zip no longer contains `positions.csv` or `watchlist.csv` — only
`.example.csv` versions — and the workflow now saves and restores both around
the unzip, so a packaging mistake cannot wipe them either.
