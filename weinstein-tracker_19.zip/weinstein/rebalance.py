"""
Index rebalance dates, and why a breakout near one is suspect.

The same defect as the earnings filter, from a different direction
------------------------------------------------------------------
Weinstein's volume rule is a proxy for institutional accumulation. The earnings
filter exists because a results-day gap satisfies that rule while meaning
something else. Index flow does exactly the same thing, and at far greater size.

When a stock is added to an index, every fund tracking that index has to buy it,
on a known date, in size, regardless of what the chart looks like. The result is
a textbook weekly bar: a decisive close above resistance on several times normal
volume. It is not accumulation. It is a forced, one-off, fully anticipated
transfer, and the move very often gives back once the flow is done.

Passive is a far larger share of the market than it was when the method was
written, which makes this a bigger contaminant now than any amount of
discretionary buying.

The dates are arithmetic, not data
----------------------------------
No network call and nothing to go stale. Two families cover almost all of it:

  Quarterly reviews  The third Friday of March, June, September and December.
                     S&P index changes and FTSE quarterly reviews both take
                     effect around here, as do quarterly futures and options
                     expiries -- which is its own reason for a strange weekly
                     bar.

  Russell recon      The FTSE Russell annual reconstitution, effective on the
                     last Friday of June. This is the single largest scheduled
                     liquidity event in US equities and it moves small caps
                     hardest, which is precisely the part of the universe the
                     whole-market expansion just added.

What this does NOT claim
------------------------
It does not assert that rebalance-week breakouts fail more often. That is a
measurable claim and it has not been measured here. It marks them, caps the
grade so they cannot sort to the top unexamined, and freezes the flag into the
forward log so the question can be answered from the record later -- the same
discipline the earnings flag follows.
"""

from __future__ import annotations

import datetime as dt

#: A break this many days either side of a rebalance date is treated as
#: potentially flow-driven. Index funds trade around the date, not only on it.
NEAR_DAYS = 7

STATUS_CLEAR = "clear"
STATUS_NEAR = "rebalance_week"

#: Rebalance flags cap the grade here. Softer than the event cap, because the
#: evidence is weaker: an earnings gap is certainly the reason for the move,
#: whereas index flow is a plausible reason among several.
CAP = "B"

_ORDER = {"A": 0, "B": 1, "C": 2, "D": 3}


def _third_friday(year: int, month: int) -> dt.date:
    d = dt.date(year, month, 1)
    # days until the first Friday, then two more weeks
    d += dt.timedelta(days=(4 - d.weekday()) % 7)
    return d + dt.timedelta(days=14)


def _last_friday(year: int, month: int) -> dt.date:
    if month == 12:
        nxt = dt.date(year + 1, 1, 1)
    else:
        nxt = dt.date(year, month + 1, 1)
    d = nxt - dt.timedelta(days=1)
    return d - dt.timedelta(days=(d.weekday() - 4) % 7)


def dates_for(year: int) -> list[tuple[dt.date, str]]:
    """Every scheduled rebalance date in one year, with what it is."""
    out = [(_third_friday(year, m), f"quarterly index review ({dt.date(year, m, 1):%B})")
           for m in (3, 6, 9, 12)]
    out.append((_last_friday(year, 6), "Russell annual reconstitution"))
    return sorted(set(out))


def classify(week_end: dt.date | None, near_days: int = NEAR_DAYS) -> dict:
    """
    Whether a signal week sits on top of a scheduled rebalance.

    `week_end` is the Friday the signal week closed on. A missing date reports
    clear rather than guessing, because a false flag here costs a real signal.
    """
    if week_end is None:
        return {"rebalance_status": STATUS_CLEAR, "rebalance_event": None,
                "rebalance_note": ""}

    for year in (week_end.year - 1, week_end.year, week_end.year + 1):
        for d, name in dates_for(year):
            if abs((week_end - d).days) <= near_days:
                return {
                    "rebalance_status": STATUS_NEAR,
                    "rebalance_event": f"{name} on {d.isoformat()}",
                    "rebalance_note": (
                        f"this break landed within {near_days} days of the {name} "
                        f"on {d.isoformat()}. Index funds buy on a schedule, in size, "
                        "regardless of the chart, so the volume that confirmed it may "
                        "be forced flow rather than accumulation"),
                }
    return {"rebalance_status": STATUS_CLEAR, "rebalance_event": None,
            "rebalance_note": ""}


def apply(rec: dict, info: dict) -> dict:
    """Folds a rebalance flag into a scored record. Only ever lowers a grade."""
    rec = dict(rec)
    rec.update({k: info.get(k) for k in ("rebalance_status", "rebalance_event")})

    sig = rec.get("signal")
    if not isinstance(sig, dict):
        return rec
    sig = dict(sig)
    sig["rebalance_status"] = info.get("rebalance_status")

    if info.get("rebalance_status") == STATUS_NEAR:
        cur = sig.get("grade")
        if cur in _ORDER and _ORDER[CAP] > _ORDER[cur]:
            sig["grade"] = CAP
            sig["notes"] = ((sig.get("notes") or "") + ("; " if sig.get("notes") else "")
                            + f"{info['rebalance_note']}. Graded down to {CAP} for that.")
        else:
            sig["notes"] = ((sig.get("notes") or "") + ("; " if sig.get("notes") else "")
                            + info["rebalance_note"] + ".")

    rec["signal"] = sig
    rec["grade"] = sig.get("grade")
    return rec
