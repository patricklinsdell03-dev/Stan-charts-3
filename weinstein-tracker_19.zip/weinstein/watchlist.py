"""
Pending orders that survive the week they were placed in.

The gap this fills
------------------
Every list the scan produces is a snapshot. A signal is visible for a while and
then ages out, and its alert levels go with it. That is fine for the scan and
useless for you, because a limit order you placed three weeks ago is still
sitting at the broker whether or not the row that produced it is still on the
page. Nothing in the system knew that order existed, so nothing re-checked
whether the idea behind it was still true.

That is the failure mode this exists to prevent: a BUY LIMIT resting at a level
that made sense a month ago, on a stock that has since closed below its 30 week
average and turned its relative strength negative. The order fills. You now own
a Stage 4 stock because a good entry outlived its own setup.

What it does
------------
Reads a file you own, one row per order you have actually placed, and each week
answers three questions about each one: has it filled, is the reasoning still
intact, and is it stale. It never places or cancels anything. It tells you which
orders to pull.

Invalidation is deliberately strict. An entry is only as good as the conditions
that justified it, and Weinstein's conditions are the ones checked: price on the
right side of the 30 week average, the average still sloping the right way, and
relative strength still positive. Any one of them failing kills the order,
because he would not take the trade on fresh analysis either.
"""

from __future__ import annotations

import os
import datetime as dt

import numpy as np
import pandas as pd

WATCHLIST = "watchlist.csv"

#: An untouched order older than this has stopped being a plan and become a
#: hope. A quarter is the same window the signal itself now stays visible for.
MAX_AGE_WEEKS = 13

COLUMNS = ["ticker", "added_on", "side", "entry_type", "entry_price", "stop", "note"]

STATUS_WAITING = "WAITING"
STATUS_TRIGGERED = "TRIGGERED"
STATUS_INVALID = "CANCEL"
STATUS_EXPIRED = "EXPIRED"
STATUS_UNKNOWN = "UNKNOWN"

TEMPLATE = """ticker,added_on,side,entry_type,entry_price,stop,note
# One row per order you have actually placed with the broker.
#   entry_type  BUY LIMIT, BUY STOP, SELL LIMIT or SELL STOP
#   added_on    the date you placed it, YYYY-MM-DD
#   stop        optional, the protective stop that goes with it
# Delete these comment lines once you add a row. Nothing here is ever placed or
# cancelled automatically: this file only reports back on what you told it.
"""


def load(path: str = WATCHLIST) -> list[dict]:
    """Rows from the file, or an empty list. Never raises on a malformed file."""
    if not os.path.exists(path):
        return []
    try:
        df = pd.read_csv(path, comment="#")
    except Exception:                                # noqa: BLE001
        return []
    if df.empty:
        return []
    out = []
    for _, r in df.iterrows():
        t = str(r.get("ticker") or "").strip()
        if not t or t.startswith("#"):
            continue
        rec = {c: (None if pd.isna(r.get(c)) else r.get(c)) for c in COLUMNS if c in df.columns}
        rec["ticker"] = t
        out.append(rec)
    return out


def ensure_template(path: str = WATCHLIST) -> None:
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(TEMPLATE)


def _f(v):
    try:
        f = float(v)
        return None if np.isnan(f) else f
    except (TypeError, ValueError):
        return None


def review_one(row: dict, feat: pd.DataFrame | None,
               asof: dt.date) -> dict:
    """
    One pending order against this week's data.

    Returns the order plus a status and a reason. The reason is the point: a
    bare CANCEL tells you nothing about whether the stock broke or you simply
    waited too long.
    """
    out = dict(row)
    out.update({"status": STATUS_UNKNOWN, "reason": "", "last_close": None,
                "weeks_waiting": None})

    entry = _f(row.get("entry_price"))
    if entry is None:
        out["reason"] = "no entry price on this row, so nothing can be checked"
        return out

    try:
        added = pd.Timestamp(row.get("added_on")).date()
    except Exception:                                # noqa: BLE001
        added = None
    if added is not None:
        out["weeks_waiting"] = max(0, (asof - added).days // 7)

    if feat is None or feat.empty:
        out["reason"] = ("not in the scanned universe this week, so the order "
                         "cannot be checked at all")
        return out

    last = feat.iloc[-1]
    close = _f(last.get("close"))
    ma30 = _f(last.get("ma30"))
    slope = _f(last.get("ma_slope_pct"))
    rs = _f(last.get("mansfield_rs"))
    out["last_close"] = close

    long = str(row.get("side") or "long").strip().lower() != "short"
    etype = str(row.get("entry_type") or "").strip().upper()

    # --- has it filled? ---------------------------------------------------
    seg = feat.loc[pd.Timestamp(added):] if added is not None else feat.tail(1)
    if not seg.empty:
        hi = pd.to_numeric(seg.get("high"), errors="coerce")
        lo = pd.to_numeric(seg.get("low"), errors="coerce")
        touched = False
        if "LIMIT" in etype:
            # A buy limit fills on the way DOWN through the level.
            touched = bool((lo <= entry).any()) if long else bool((hi >= entry).any())
        else:
            # A stop order fills on the way THROUGH in the trade's direction.
            touched = bool((hi >= entry).any()) if long else bool((lo <= entry).any())
        if touched:
            out["status"] = STATUS_TRIGGERED
            out["reason"] = (f"price has traded through {entry:g} since you placed this, "
                             "so it has almost certainly filled. Move it to positions.csv "
                             "so the weekly management rules start applying to it.")
            return out

    # --- is the reasoning still intact? -----------------------------------
    broken = []
    if close is not None and ma30 is not None:
        if long and close < ma30:
            broken.append("price has closed below its 30 week average")
        if not long and close > ma30:
            broken.append("price has closed back above its 30 week average")
    if slope is not None:
        if long and slope <= 0:
            broken.append("the 30 week average has stopped rising")
        if not long and slope >= 0:
            broken.append("the 30 week average has stopped falling")
    if rs is not None:
        if long and rs < 0:
            broken.append(f"relative strength has turned negative ({rs:.1f})")
        if not long and rs > 0:
            broken.append(f"relative strength has turned positive ({rs:.1f})")

    stop = _f(row.get("stop"))
    if stop is not None and close is not None:
        if long and close <= stop:
            broken.append(f"price is already below the stop you set at {stop:g}")
        if not long and close >= stop:
            broken.append(f"price is already above the stop you set at {stop:g}")

    if broken:
        out["status"] = STATUS_INVALID
        out["reason"] = ("cancel this order: " + "; ".join(broken) +
                         ". The entry level is unchanged but the setup that "
                         "justified it is not, and a resting order does not know that.")
        return out

    # --- is it simply stale? ----------------------------------------------
    if out["weeks_waiting"] is not None and out["weeks_waiting"] > MAX_AGE_WEEKS:
        out["status"] = STATUS_EXPIRED
        out["reason"] = (f"{out['weeks_waiting']} weeks without filling. The chart has "
                         "moved on; re-derive the level rather than leaving this one out.")
        return out

    out["status"] = STATUS_WAITING
    dist = ((entry / close - 1.0) * 100.0) if close else None
    out["reason"] = ("setup still intact"
                     + (f", price is {abs(dist):.1f}% "
                        f"{'above' if dist and dist < 0 else 'below'} the entry"
                        if dist is not None else ""))
    return out


def review(rows: list[dict], feats: dict[str, pd.DataFrame],
           asof: dt.date | None = None) -> list[dict]:
    asof = asof or dt.date.today()
    return [review_one(r, feats.get(str(r.get("ticker", "")).strip()), asof)
            for r in rows]


def summarise(reviewed: list[dict]) -> str:
    if not reviewed:
        return ""
    counts: dict[str, int] = {}
    for r in reviewed:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    return ", ".join(f"{v} {k.lower()}" for k, v in sorted(counts.items()))
